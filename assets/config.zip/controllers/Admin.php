<?php
defined('BASEPATH') or exit('No direct script access allowed');
/**
 * 
 */
class Admin extends CI_Controller
{

	function __construct()
	{
		parent::__construct();
		$this->load->model('Pengaturan_mdl');
		$this->load->model('Admin_mdl');
		$this->load->helper('url');
	}

	//admin list
	public function index($id = 0)
	{
		$data = array(
			'title' => 'Admin',
			'header1' => 'Admin',
			'admin' => $this->Admin_mdl->getAll('admin')->result(),
			'pengaturan' => $this->Pengaturan_mdl->getById($id),
			'jlh_admin' => $this->Admin_mdl->countAll('admin')
		);
		$this->load->view('admin/_partials/head.php', $data);
		$this->load->view('admin/admin.php');
	}

	//tambah admin
	public function signup($id = 0)
	{
		if (isset($_POST['btnsimpan'])) {
			$data = array(
				'id_admin' => '',
				'nama' => $this->input->post('txtnama'),
				'username' => $this->input->post('txtusername'),
				'password' => $this->input->post('txtpassword'),
				'email' => $this->input->post('txtemail'),
				'telp' => $this->input->post('txttelp')
			);
			$this->Admin_mdl->save('admin', $data);
			redirect('main/dashboard');
		} else {
			$data = array(
				'title' => 'Sign Up',
				'header1' => 'Sign Up',
				'pengaturan' => $this->Pengaturan_mdl->getById($id),
				'admin' => $this->Admin_mdl->getAll('admin')->result()
			);
			$this->load->view('admin/_partials/head.php', $data);
			$this->load->view('admin/signup', $data);
		}
	}

	//login
	public function login($id = 0)
	{
		if (isset($_POST['btnlogin'])) {
			$username = $this->input->post('txtusername');
			$password = $this->input->post('txtpassword');
			$kondisi = array(
				'username' => $username,
				'password' => $password
			);

			$cek_data = $this->Admin_mdl->cek_data('admin', $kondisi);
			//numrows = cek data
			if ($cek_data->num_rows() > 0) {
				$data = $cek_data->result();
				$login = array(
					'username' => $username,
					'status' => 'active'
				);

				$this->session->set_userdata($login);
				//$username = $this->session->userdata('admin')($login);
				//$this->Admin_mdl->ambil($username);
				session_start();
				echo '<script>alert("Berhasil Login!")</script>';
				redirect('main/dashboard');
			} else {
				echo '<script>alert("Akun tidak ditemukan!")</script>';
				redirect('admin/login');
			}
		} else {
			$data = array(
				'title' => 'Login',
				'header1' => 'Login',
				'pengaturan' => $this->Pengaturan_mdl->getById($id),
				'admin' => $this->Admin_mdl->getAll('admin')->result()
			);
			$this->load->view('admin/_partials/head.php', $data);
			$this->load->view('admin/login', $data);
		}
	}


	//Berfungsi untuk melakukan proses logout melalui halaman editor
	public function logout()
	{
		$this->session->sess_destroy();
		redirect('admin/login');
	}

	//tambah admin
	public function tambah($id = 0)
	{
		if (isset($_POST['btnsimpan'])) {
			$data = array(
				'id_admin' => '',
				'nama' => $this->input->post('txtnama'),
				'username' => $this->input->post('txtusername'),
				'password' => $this->input->post('txtpassword'),
				'email' => $this->input->post('txtemail'),
				'telp' => $this->input->post('txttelp')
			);
			$this->Admin_mdl->save('admin', $data);
			redirect('admin/index');
		} else {
			$data = array(
				'title' => 'Tambah Admin',
				'header1' => 'Tambah Admin',
				'pengaturan' => $this->Pengaturan_mdl->getById($id),
				'admin' => $this->Admin_mdl->getAll('admin')->result()
			);
			$this->load->view('admin/_partials/head.php', $data);
			$this->load->view('admin/addadmin', $data);
		}
	}

	//edit admin
	public function edit($id_admin = null, $id = 0)
	{
		if (isset($_POST['btnsimpan'])) {
			$data = array(
				'nama' => $this->input->post('txtnama'),
				'username' => $this->input->post('txtusername'),
				'password' => $this->input->post('txtpassword'),
				'email' => $this->input->post('txtemail'),
				'telp' => $this->input->post('txttelp')
			);
			//update admin
			$this->Admin_mdl->update($id_admin, $data);
			redirect('admin/index');
		} else {
			$data = array(
				'title' => 'Edit Admin',
				'header1' => 'Edit Admin',
				'pengaturan' => $this->Pengaturan_mdl->getById($id),
				'admin' => $this->Admin_mdl->getById($id_admin),
			);
			$this->load->view('admin/_partials/head.php', $data);
			$this->load->view('admin/editadmin', $data);
		}
	}

	//hapus admin
	public function delete()
	{
		$this->db->delete('admin');
		redirect('admin/index');
	}
}
