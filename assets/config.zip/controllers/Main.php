<?php
defined('BASEPATH') or exit('No direct script access allowed');
/**
 *	
 */
class Main extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('Admin_mdl');
		$this->load->model('Produk_mdl');
		$this->load->model('Outlet_mdl');
		$this->load->model('Pengaturan_mdl');
		$this->load->helper('url');
	}

	//signup outlet
	public function signup($id = 0)
	{
		if (isset($_POST['btntambah'])) {
			$kondisi = array(
				'nama' => $this->input->post('txtnama'),
				'toko' => $this->input->post('txttoko'),
				'hp' => $this->input->post('txthp'),
				'email' => $this->input->post('txtemail'),
				'password' => $this->input->post('txtpassword'),
				'alamat' => $this->input->post('txtalamat'),
				'pos' => $this->input->post('txtpos'),
				'pin' => $this->input->post('pin'),
			);
			$this->Outlet_mdl->save('outlet', $kondisi);
		} else {
			$data = array(
				'title' => 'Sign Up',
				'header1' => 'Sign Up',
				'pengaturan' => $this->Pengaturan_mdl->getById($id)
			);
			$this->load->view('admin/_partials/head.php', $data);
			$this->load->view('admin/signup.php', $data);
		}
	}

	//portal kontak salesman
	public function portal($id = 0)
	{
		$data = array(
			'title' => 'Portal Kontak Salesman',
			'header1' => 'Pilih Metode Pemesanan',
			'pengaturan' => $this->Pengaturan_mdl->getById($id)
		);
		$this->load->view('admin/_partials/head.php', $data);
		$this->load->view('public/_partials/navbar.php', $data);
		$this->load->view('public/portal.php', $data);
	}

	//home admin
	public function dashboard($id = 0)
	{
		if (isset($_POST['btnsimpan'])) {

			$config['upload_path'] = './assets/frontend/img/';
			$config['allowed_types'] = 'jpg|jpeg|png|webp|gif';
			$this->load->library('upload', $config);
			$upload_favicon = $_FILES['txtfavicon']['name'];
			$upload_logo = $_FILES['txtlogo']['name'];

			$this->upload->do_upload('txtlogo');
			$this->upload->do_upload('txtfavicon');
			$favicon = $this->upload->data('file_name');
			$logo = $this->upload->data('file_name');

			$input = array(
				'judul' => $this->input->post('txtjudul'),
				'favicon' => $upload_favicon,
				'logo' => $upload_logo,
				'alamat' => $this->input->post('txtalamat'),
				'email' => $this->input->post('txtemail'),
				'telp' => $this->input->post('txttelp'),
				'metadesc' => $this->input->post('txtmetadesc'),
				'fb' => $this->input->post('txtfb'),
				'ig' => $this->input->post('txtig')
			);
			//edit pengaturan
			$this->Pengaturan_mdl->update($id, $input);
		} else {
			$data = array(
				'title' =>  'Dashboard',
				'header1' =>  'Dashboard',
				'header2' =>  'Data Website',
				'pengaturan' => $this->Pengaturan_mdl->getById($id),
				'jlh_outlet' => $this->Outlet_mdl->countAll('outlet'),
				'jlh_produk' => $this->Produk_mdl->countAll('produk'),
				'jlh_admin' => $this->Admin_mdl->countAll('admin'),
			);
			$this->load->view('admin/_partials/head.php', $data);
			$this->load->view('admin/index.php', $data);
		}
	}

	//index home
	public function index($id = 0)
	{
		$data = array(
			'title' => 'Selamat Datang di lsi',
			'header1' => 'Selamat Datang di PT Legen Sukses Inventif',
			'pengaturan' => $this->Pengaturan_mdl->getById($id),
			'produk' => $this->Produk_mdl->getAll('produk')->result()
		);
		$this->load->view('public/_partials/head.php', $data);
		$this->load->view('public/_partials/navbar.php', $data);
		$this->load->view('public/index.php', $data);
	}

	//about
	public function about($id = 0)
	{
		$data = array(
			'title' => 'About Us',
			'header1' => 'About Us',
			'pengaturan' => $this->Pengaturan_mdl->getById($id)
		);
		$this->load->view('public/_partials/headtest.php', $data);
		$this->load->view('public/about.php', $data);
		$this->load->view('public/_partials/foottest.php', $data);
	}

	//produk
	public function produk($id = 0)
	{
		$data = array(
			'title' => 'Produk',
			'header1' => 'Produk',
			'pengaturan' => $this->Pengaturan_mdl->getById($id),
			'produk' => $this->Produk_mdl->getAll('produk')->result()
		);
		$this->load->view('public/_partials/head.php', $data);
		$this->load->view('public/_partials/navbar.php', $data);
		$this->load->view('public/produk.php', $data);
	}

	//detail produk
	public function detail($id_produk = null, $id = 0)
	{
		$data = array(
			'title' => 'Produk',
			'header1' => 'Produk',
			'pengaturan' => $this->Pengaturan_mdl->getById($id),
			'produk' => $this->Produk_mdl->GetById($id_produk)
		);
		$this->load->view('public/_partials/head.php', $data);
		$this->load->view('public/_partials/navbar.php', $data);
		$this->load->view('public/detail.php', $data);
	}
}
