<?php
defined('BASEPATH') or exit('No direct script access allowed');
/**
 * 
 */
class Outlet extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('Pengaturan_mdl');
		$this->load->model('Outlet_mdl');
		$this->load->helper('url');
	}

	//outlet list
	public function index($id = 0)
	{
		$data = array(
			'title' => 'Outlet',
			'header1' => 'Outlet',
			'outlet' => $this->Outlet_mdl->getAll('outlet')->result(),
			'pengaturan' => $this->Pengaturan_mdl->getById($id),
			'jlh_outlet' => $this->Outlet_mdl->countAll('outlet')
		);
		$this->load->view('admin/_partials/head.php', $data);
		$this->load->view('admin/outlet.php', $data);
	}

	//login outlet
	public function login($id = 0)
	{
		if (isset($_POST['btnlogin'])) {
			$kondisi = array(
				'telp' => $this->input->post('txttelp'),
				'pin' => $this->input->post('txtpin')
			);
			$cek_data = $this->Outlet_mdl->cek_data('outlet', $kondisi);

			if ($cek_data->num_rows() > 0) {
				$data = $cek_data->result();
				$login = array(
					'status' => 'active'
				);
				echo '<script>alert("Berhasil Login")</script>';
				$this->session->set_userdata('outlet', $login);
				//$username = $this->session->userdata('outlet')($login);
				//$this->Petugas_mdl->ambil($username);
				session_start();

				redirect('main/portal');
			} else {
				echo '<script>alert("email tidak ditemukan")</script>';
				redirect('outlet/login');
			}
		} else {
			$data = array(
				'title' => 'Login',
				'header1' => 'Login',
				'pengaturan' => $this->Pengaturan_mdl->getById($id),
			);
			$this->load->view('admin/_partials/head.php', $data);
			$this->load->view('public/login.php', $data);
		}
	}

	//tambah outlet
	public function signup($id = 0)
	{
		if (isset($_POST['btnsimpan'])) {
			$config['upload_path'] = './upload/outlet/';
			$config['allowed_types'] = 'jpg|jpeg|png|webp|gif';

			$this->load->library('upload', $config);
			$nama_gambar = $_FILES['txtfoto']['name'];

			if ($nama_gambar) {
				$this->upload->do_upload('txtfoto');
				$this->upload->data('file_name');

				$data = array(
					'id_outlet' => '',
					'nama' => $this->input->post('txtnama'),
					'outlet' => $this->input->post('txtoutlet'),
					'telp' => $this->input->post('txttelp'),
					'email' => $this->input->post('txtemail'),
					'alamat' => $this->input->post('txtalamat'),
					'pos' => $this->input->post('txtpos'),
					'pin' => $this->input->post('txtpin'),
					'foto' => $nama_gambar
				);

				$this->Outlet_mdl->save('outlet', $data);
				redirect('outlet/login');
			}
		} else {
			$data = array(
				'title' => 'Sign Up',
				'header1' => 'Sign Up',
				'pengaturan' => $this->Pengaturan_mdl->getById($id),
				'outlet' => $this->Outlet_mdl->getAll('outlet')->result()
			);
			$this->load->view('admin/_partials/head.php', $data);
			$this->load->view('public/signup', $data);
		}
	}

	//tambah outlet
	public function tambah($id = 0)
	{
		if (isset($_POST['btnsimpan'])) {
			$config['upload_path'] = './upload/outlet/';
			$config['allowed_types'] = 'jpg|jpeg|png|webp|gif';

			$this->load->library('upload', $config);
			$nama_gambar = $_FILES['txtfoto']['name'];

			if ($nama_gambar) {
				$this->upload->do_upload('txtfoto');
				$this->upload->data('file_name');

				$data = array(
					'id_outlet' => '',
					'nama' => $this->input->post('txtnama'),
					'outlet' => $this->input->post('txtoutlet'),
					'telp' => $this->input->post('txttelp'),
					'email' => $this->input->post('txtemail'),
					'alamat' => $this->input->post('txtalamat'),
					'pos' => $this->input->post('txtpos'),
					'pin' => $this->input->post('txtpin'),
					'foto' => $nama_gambar
				);

				$this->Outlet_mdl->save('outlet', $data);
				redirect('outlet/index');
			};
		} else {
			$data = array(
				'title' => 'Tambah Outlet',
				'header1' => 'Tambah Outlet',
				'pengaturan' => $this->Pengaturan_mdl->getById($id),
				'outlet' => $this->Outlet_mdl->getAll('outlet')->result()
			);
			$this->load->view('admin/_partials/head.php', $data);
			$this->load->view('admin/addoutlet', $data);
		}
	}

	//edit outlet
	public function edit($id_outlet = null, $id = 0)
	{
		if (isset($_POST['btnsimpan'])) {
			$config['upload_path'] = './upload/outlet/';
			$config['allowed_types'] = 'jpg|jpeg|png|webp|gif';
			$this->load->library('upload', $config);
			$nama_gambar = $_FILES['txtfoto']['name'];

			if ($nama_gambar) {
				$this->upload->do_upload('txtfoto');
				$foto = $this->upload->data('file_name');

				$data = array(
					'nama' => $this->input->post('txtnama'),
					'outlet' => $this->input->post('txtoutlet'),
					'telp' => $this->input->post('txttelp'),
					'email' => $this->input->post('txtemail'),
					'alamat' => $this->input->post('txtalamat'),
					'pos' => $this->input->post('txtpos'),
					'pin' => $this->input->post('txtpin'),
					'foto' => $nama_gambar,
				);
				//edit outlet
				$this->Outlet_mdl->update($id_outlet, $data);
				redirect('outlet/index');
			};
		} else {
			$data = array(
				'title' => 'Edit Outlet',
				'header1' => 'Edit Outlet',
				'pengaturan' => $this->Pengaturan_mdl->getById($id),
				'outlet' => $this->Outlet_mdl->getById($id_outlet),
			);
			$this->load->view('admin/_partials/head.php', $data);
			$this->load->view('admin/editoutlet', $data);
		}
	}

	//hapus outlet
	public function delete($id_outlet)
	{
		$this->Outlet_mdl->delete($id_outlet);
		redirect('outlet/index');
	}
}
