<?php
defined('BASEPATH') or exit('No direct script access allowed');
/**
 * 
 */
class Pengaturan extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('Pengaturan_mdl');
		$this->load->helper('url');
	}

	//edit Pengaturan
	public function edit($id = 0)
	{
		if (isset($_POST['btnsimpan'])) {

			$config['upload_path'] = './assets/frontend/img/';
			$config['allowed_types'] = 'jpg|jpeg|png|webp|gif';
			$this->load->library('upload', $config);
			$upload_favicon = $_FILES['txtfavicon']['name'];
			$upload_logo = $_FILES['txtlogo']['name'];

			$this->upload->do_upload('txtlogo');
			$this->upload->do_upload('txtfavicon');
			$favicon = $this->upload->data('file_name');
			$logo = $this->upload->data('file_name');

			$input = array(
				'judul' => $this->input->post('txtjudul'),
				'favicon' => $upload_favicon,
				'logo' => $upload_logo,
				'alamat' => $this->input->post('txtalamat'),
				'hp' => $this->input->post('txthp'),
				'metadesc' => $this->input->post('txtmetadesc')
			);
			//edit pengaturan
			$this->Pengaturan_mdl->update($id, $input);
			redirect('main/dashboard');
		} else {
			$data = array(
				'title' => 'Edit Pengaturan',
				'header1' => 'Edit Pengaturan',
				'pengaturan' => $this->Pengaturan_mdl->getById($id),
			);
			$this->load->view('admin/_partials/head.php', $data);
			$this->load->view('admin/editpengaturan', $data);
		}
	}
}
