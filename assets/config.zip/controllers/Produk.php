<?php
defined('BASEPATH') or exit('No direct script access allowed');
/**
 * 
 */
class Produk extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('Pengaturan_mdl');
		$this->load->model('Produk_mdl');
		$this->load->helper('url');
	}

	//produk list
	public function index($id = 0)
	{
		$data = array(
			'title' => 'List Produk',
			'header1' => 'List Produk',
			'produk' => $this->Produk_mdl->getAll('produk')->result(),
			'pengaturan' => $this->Pengaturan_mdl->getById($id),
			'jlh_produk' => $this->Produk_mdl->countAll('produk')
		);
		$this->load->view('admin/_partials/head.php', $data);
		$this->load->view('admin/produk.php', $data);
	}

	//tambah produk
	public function tambah($id = 0)
	{
		if (isset($_POST['btnsimpan'])) {
			$config['upload_path'] = './upload/produk/';
			$config['allowed_types'] = 'jpg|jpeg|png|webp|gif';

			$this->load->library('upload', $config);
			$nama_gambar = $_FILES['txtfoto']['name'];

			if ($nama_gambar) {
				$this->upload->do_upload('txtfoto');
				$foto = $this->upload->data('file_name');
				$data = array(
					'id_produk' => '',
					'nama' => $this->input->post('txtnama'),
					'kategori' => $this->input->post('txtkategori'),
					'keterangan' => $this->input->post('txtketerangan'),
					'foto' => $nama_gambar
				);
				$this->Produk_mdl->save('produk', $data);
				redirect('produk/index');
			};
		} else {
			$data = array(
				'title' => 'Tambah Produk',
				'header1' => 'Tambah Produk',
				'pengaturan' => $this->Pengaturan_mdl->getById($id),
				'produk' => $this->Produk_mdl->getAll('produk')->result()
			);
			$this->load->view('admin/_partials/head.php', $data);
			$this->load->view('admin/addproduk', $data);
		}
	}

	//edit produk
	public function edit($id_produk = null, $id = 0)
	{
		if (isset($_POST['btnsimpan'])) {
			$config['upload_path'] = './upload/produk/';
			$config['allowed_types'] = 'jpg|jpeg|png|webp|gif';
			$this->load->library('upload', $config);
			$nama_gambar = $_FILES['txtfoto']['name'];

			if ($nama_gambar) {
				$this->upload->do_upload('txtfoto');
				$this->upload->data('file_name');

				$data = array(
					'nama' => $this->input->post('txtnama'),
					'kategori' => $this->input->post('txtkategori'),
					'keterangan' => $this->input->post('txtketerangan'),
					'foto' => $nama_gambar,
				);
				//edit produk
				$this->Produk_mdl->update($id_produk, $data);
				redirect('produk/index');
			};
		} else {
			$data = array(
				'title' => 'Edit Produk',
				'header1' => 'Edit Produk',
				'pengaturan' => $this->Pengaturan_mdl->getById($id),
				'produk' => $this->Produk_mdl->getById($id_produk)
			);
			$this->load->view('admin/_partials/head.php', $data);
			$this->load->view('admin/editproduk', $data);
		}
	}

	//hapus produk
	public function delete($id_produk)
	{
		delete_files('upload/produk/', $id_produk);
		$this->Produk_mdl->delete($id_produk);
		redirect('produk/index');
	}
}
