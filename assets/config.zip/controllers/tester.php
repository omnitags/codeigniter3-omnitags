<?php
defined('BASEPATH') or exit('No direct script access allowed');
/**
 * 
 */
class tester extends CI_Controller
{
    public function index()
    {
        $this->load->view('public/_partials/headtest');
        $this->load->view('public/tester');
        $this->load->view('public/_partials/footer');
    }
}
