<div class="row">
  <div class="col-auto">
    <div class="card my-2">
      <div class="card-body">
        <h5 class="card-title">Jumlah Admin</h5>
        <h3 class="card-text"><?php echo $jlh_admin ?></h3>
      </div>
    </div>
  </div>
</div>