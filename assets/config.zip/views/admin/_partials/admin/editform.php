<!--edit admin-->
<form action="" method="POST">
    <div class="form-group col-md-6">
        <label for="inputId_admin">Id Admin</label>
        <input name="txtid_admin" type="text" class="form-control" disabled id="inputId_admin" value="<?php echo $admin->id_admin ?>">
    </div>

    <div class="form-row col-md-6">
        <div class="form-group col-md-6">
            <label for="inputNama">Nama</label>
            <input name="txtnama" type="text" class="form-control" id="inputNama" required value="<?php echo $admin->nama ?>">
        </div>
        <div class="form-group col-md-6">
            <label for="inputPassword">Password</label>
            <input name="txtpassword" type="password" class="form-control" id="inputPassword" required value="<?php echo $admin->password ?>">
        </div>
    </div>

    <div class="form-row col-md-6">
        <div class="form-group col-md-6">
            <label for="inputUsername">Username</label>
            <input name="txtusername" type="text" class="form-control" id="inputUsername" required value="<?php echo $admin->username ?>">
        </div>
        <div class="form-group col-md-6">
            <label for="inputKonfirmasi">Konfirmasi Password</label>
            <input name="txtkonfirmasi" type="password" class="form-control" id="inputKonfirmasi" required>
        </div>
    </div>

    <div class="form-row col-md-6">
        <div class="form-group col-md-6">
            <label for="inputEmail">Email</label>
            <input name="txtemail" type="text" class="form-control" id="inputEmail" required value="<?php echo $admin->email ?>">
        </div>
        <div class="form-group col-md-6">
            <label for="inputTelp">Telp (contoh : 812345678901)</label>
            <input name="txttelp" type="text" class="form-control" id="inputTelp" required value="<?php echo $admin->telp ?>">
        </div>
    </div>

    <a class="btn btn-secondary" href="<?php echo site_url('admin/index'); ?>" name="btnbatal">BATAL</a>
    <button class="btn btn-danger" type="reset" name="btnreset">RESET</button>
    <button class="btn btn-success" type="submit" name="btnsimpan">SIMPAN</button>
</form>