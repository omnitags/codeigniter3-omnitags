<base href="<?php echo base_url(); ?>">
<!--sign up admin-->

<form class="user" method="post" action="<?= site_url('admin/signup'); ?>">
    <div class="form-group">
        <label for="inputNama">Nama Lengkap/Full Name</label>
        <input type="text" class="form-control form-control-user" id="inputNama" name="txtnama" placeholder="">
    </div>
    <div class="form-group">
        <label for="inputUsername">Username</label>
        <input type="text" class="form-control form-control-user" id="inputUsername" name="txtusername" placeholder="">
    </div>
    <div class="form-group">
        <label for="inputPassword1">Password</label>
        <input type="password" class="form-control form-control-user" id="inputPassword1" name="txtpasssword" placeholder="">
    </div>
    <div class="form-group">
        <label for="inputPassword2">Repeat Password</label>
        <input type="password" class="form-control form-control-user" id="inputPassword2" name="txtkonfirm" placeholder="">
    </div>
    <div class="form-group">
        <label for="inputEmail">E-mail</label>
        <input type="text" class="form-control form-control-user" id="inputEmail" name="txtemail" placeholder="">
    </div>
    <div class="form-group">
        <label for="inputTelp">No HP/Number Phone</label>
        <input type="text" class="form-control form-control-user" id="inputTelp" name="txttelp" placeholder="">
    </div>
    <small>Sudah punya akun? <span><a href="<?= site_url('admin/login'); ?>">Login</a> </span></small>
    <div class="centering">
        <button type="submit" class="register" name="btnsimpan">SIGNUP</button>
    </div>
</form>