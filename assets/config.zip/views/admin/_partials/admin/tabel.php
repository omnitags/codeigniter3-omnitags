<table class="table-sm table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">
    <thead>
        <tr>
            <th>Id Admin</th>
            <th>Nama</th>
            <th>Username</th>
            <th>Password</th>
            <th>Email</th>
            <th>Telp</th>
            <th>Fungsi</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($admin as $s) { ?>
            <tr>
                <td class="text-break small" width="10%">
                    <?php echo $s->id_admin ?>
                </td>
                <td class="text-break small" width="15%">
                    <?php echo $s->nama ?>
                </td>
                <td class="text-break small" width="10%">
                    <?php echo $s->username ?>
                </td>
                <td class="text-break small" width="10%">
                    <?php echo $s->password ?>
                </td>
                <td class="text-break small" width="20%">
                    <?php echo $s->email ?>
                </td>
                <td class="text-break small" width="10%">
                    <?php echo $s->telp ?>
                </td>
                <td class="" width="12%">
                    <a class="btn btn-warning text-white my-2 col-lg-auto" href="<?php echo site_url('admin/edit/' . $s->id_admin) ?>">Edit</a>

                    <a class="btn btn-danger text-white my-2 col-lg-auto" href="<?php echo site_url('admin/delete/' . $s->id_admin) ?>">Hapus</a>
                </td>
            </tr>
        <?php } ?>

    </tbody>
</table>