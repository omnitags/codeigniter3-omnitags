<base href="<?php echo base_url(); ?>">
<!--  Footer PT LSI Dengan Grid -->
<footer style="width: 100%">
  <div class="container-fluid" height: 120px>
    <div class="container align-items-center" width: auto;>
      <div class="row justify-content-start">
        @Copyright
      </div>

    </div>
  </div>

</footer>