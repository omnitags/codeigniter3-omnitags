<base href="<?php echo base_url(); ?>" />
<!--tambah outlet-->

<form enctype="multipart/form-data" action="<?= site_url('outlet/tambah'); ?>" method="POST">
  <div class="form-row col-md-6">
    <div class="form-group col-md-6">
      <label for="inputNama">Nama</label>
      <input name="txtnama" type="text" class="form-control" id="inputNama" required>
    </div>
    <div class="form-group col-md-6">
      <label for="inputOutlet">Outlet</label>
      <input name="txtoutlet" type="text" class="form-control" id="inputOutlet" required>
    </div>
  </div>

  <div class="form-row col-md-6">
    <div class="form-group col-md-6">
      <label for="inputTelp">Telp (contoh : 812345678901)</label>
      <input name="txttelp" type="text" class="form-control" id="inputtelp" required>
    </div>
    <div class="form-group col-md-6">
      <label for="inputEmail">Email</label>
      <input name="txtemail" type="text" class="form-control" id="inputEmail" required>
    </div>
  </div>

  <div class="form-group col-md-6">
    <label for="textareaAlamat">Alamat</label>
    <textarea name="txtalamat" class="form-control" id="textareaAlamat" rows="3"></textarea>
  </div>

  <div class="form-row col-md-6">
    <div class="form-group col-md">
      <label for="inputPos">Pos</label>
      <input name="txtpos" type="text" class="form-control" id="inputPos" required>
    </div>
    <div class="form-group col-md">
      <label for="inputPin">Pin</label>
      <input name="txtpin" type="password" class="form-control" id="inputPin" required>
    </div>
    <div class="form-group col-md">
      <label for="inputKonfirmasi">Korfirmasi Pin</label>
      <input name="txtkonfirmasi" type="password" class="form-control" id="inputKonfirmasi" required>
    </div>
  </div>

  <div class="form-group col-md-6">
    <label for="inputFoto">Foto</label>
    <input name="txtfoto" type="file" class="form-control-file" id="inputFoto" required>
    <small>Nama file tanpa spasi (contoh : tiresma3dnmaxxis)</small>
  </div>

  <a class="btn btn-secondary" href="<?php echo site_url('outlet/index'); ?>">BACK</a>
  <button class="btn btn-danger" type="reset">RESET</button>
  <button class="btn btn-success" type="submit" name="btnsimpan">Buat Akun</button>
</form>