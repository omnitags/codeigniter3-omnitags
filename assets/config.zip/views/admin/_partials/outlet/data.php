<div class="row">
  <div class="col-auto my-2">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Jumlah Outlet</h5>
        <h3 class="card-text"><?php echo $jlh_outlet ?></h3>
      </div>
    </div>
  </div>
</div>