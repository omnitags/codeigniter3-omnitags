<!--edit outlet-->

<form action="" method="POST" enctype="multipart/form-data">
  <div class="form-group col-md-6">
    <label for="inputId_outlet">Id Outlet</label>
    <input name="txtid_outlet" type="text" class="form-control" id="inputId_outlet" disabled value="<?php echo $outlet->id_outlet ?>">
  </div>

  <div class="form-row col-md-6">
    <div class="form-group col-md-6">
      <label for="inputNama">Nama</label>
      <input name="txtnama" type="text" class="form-control" id="inputNama" required value="<?php echo $outlet->nama ?>">
    </div>
    <div class="form-group col-md-6">
      <label for="inputOutlet">Outlet</label>
      <input name="txtoutlet" type="text" class="form-control" id="inputOutlet" required value="<?php echo $outlet->outlet ?>">
    </div>
  </div>

  <div class="form-row col-md-6">
    <div class="form-group col-md-6">
      <label for="inputTelp">Telp (contoh : 812345678901)</label>
      <input name="txttelp" type="text" class="form-control" id="inputTelp" required value="<?php echo $outlet->telp ?>">
    </div>
    <div class="form-group col-md-6">
      <label for="inputEmail">Email</label>
      <input name="txtemail" type="text" class="form-control" id="inputEmail" required value="<?php echo $outlet->email ?>">
    </div>
  </div>

  <div class="form-group col-md-6">
    <label for="textareaAlamat">Alamat</label>
    <textarea name="txtalamat" class="form-control" id="textareaAlamat" rows="3"><?php echo $outlet->alamat ?></textarea>
  </div>

  <div class="form-row col-md-6">
    <div class="form-group col-md">
      <label for="inputHp">Pos</label>
      <input name="txtpos" type="text" class="form-control" id="inputHp" required value="<?php echo $outlet->pos ?>">
    </div>
    <div class="form-group col-md">
      <label for="inputPin">Pin</label>
      <input name="txtpin" type="password" class="form-control" id="inputPin" required value="<?php echo $outlet->pin ?>">
    </div>
    <div class="form-group col-md">
      <label for="inputKonfirmasi">Korfirmasi Pin</label>
      <input name="txtkonfirmasi" type="password" class="form-control" id="inputKonfirmasi" required>
    </div>
  </div>

  <div class="form-group col-md-6">
    <label for="inputFoto">Foto</label>
    <input name="txtfoto" type="file" class="form-control-file" id="inputFoto" required value="<?php echo $outlet->foto ?>">
    <small>Nama file tanpa spasi (contoh : tiresma3dnmaxxis)</small>
  </div>

  <a class="btn btn-secondary" href="<?php echo site_url('outlet/index'); ?>">BATAL</a>
  <button class="btn btn-danger" type="reset">RESET</button>
  <button class="btn btn-success" type="submit" name="btnsimpan">SIMPAN</button>
</form>