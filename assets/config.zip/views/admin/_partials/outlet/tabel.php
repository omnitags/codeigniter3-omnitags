<table class="table-sm table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">
    <thead>
        <tr>
            <th>Id Outlet</th>
            <th>Nama</th>
            <th>Outlet</th>
            <th>Telp</th>
            <th>Email</th>
            <th>Alamat</th>
            <th>Pos</th>
            <th>Pin</th>
            <th>Foto</th>
            <th>Fungsi</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($outlet as $s) { ?>
            <tr>
                <td class="text-break small" width="7%">
                    <?php echo $s->id_outlet ?>
                </td>
                <td class="text-break small" width="10%">
                    <?php echo $s->nama ?>
                </td>
                <td class="text-break small" width="10%">
                    <?php echo $s->outlet ?>
                </td>
                <td class="text-break small" width="8%">
                    <?php echo $s->telp ?>
                </td>
                <td class="text-break small" width="13%">
                    <?php echo $s->email ?>
                </td>
                <td class="text-break small" width="18%">
                    <?php echo $s->alamat ?>
                </td>
                <td class="text-break" width="5%">
                    <?php echo $s->pos ?>
                </td>
                <td class="text-break" width="5%">
                    <?php echo $s->pin ?>
                </td>
                <td class="text-break" width="10%">
                    <img src="<?php echo base_url('upload/outlet/' . $s->foto) ?>" width="128" />
                </td>
                <td class="" width="12%">
                    <a class="btn btn-warning text-white my-2 col-lg-auto" href="<?php echo site_url('outlet/edit/' . $s->id_outlet) ?>">Edit</a>

                    <a class="btn btn-danger text-white my-2 col-lg-auto" href="<?php echo site_url('outlet/delete/' . $s->id_outlet) ?>">Hapus</a>
                </td>
            </tr>
        <?php } ?>

    </tbody>
</table>