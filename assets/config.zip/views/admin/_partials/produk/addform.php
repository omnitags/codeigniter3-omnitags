<base href="<?php echo base_url(); ?>">
<!-- tambah produk -->

<form enctype="multipart/form-data" action="<?= site_url('produk/tambah'); ?>" method="POST">
  <div class="form-group col-md-6">
    <label for="inputNama">Nama</label>
    <input name="txtnama" type="text" class="form-control" id="inputNama" required>
  </div>

  <div class="form-row col-md-6">
    <div class="form-group col-md-6">
      <label for="inputKategori">Kategori</label>
      <select name="txtkategori" class="form-control" id="inputKategori">
        <option value="" disabled hidden selected>pilih kategori...</option>
        <option>Battery</option>
        <option>Bearing</option>
        <option>Brake Parts</option>
        <option>Cables</option>
        <option>Chain & Gear</option>
        <option>Cluth</option>
        <option>CVT Parts</option>
        <option>Electric Parts</option>
        <option>Engine Parts</option>
        <option>Gasket</option>
        <option>Other Parts</option>
        <option>Suspension Parts</option>
        <option>Tires</option>
        <option>Wheel Parts</option>
      </select>
    </div>
    <div class="form-group col-md-6">
      <label for="inputFoto">Foto</label>
      <input name="txtfoto" type="file" class="form-control-file" id="inputFoto" required>
      <small>Nama file tanpa spasi (contoh : tiresma3dnmaxxis)</small>
    </div>
  </div>

  <div class="form-group col-md-6">
    <label for="textareaAlamat">Keterangan</label>
    <textarea name="txtketerangan" class="form-control" id="textareaAlamat" rows="3"></textarea>
  </div>

  <a class="btn btn-secondary" href="<?php echo site_url('produk/index'); ?>">BACK</a>
  <button class="btn btn-danger" type="reset">RESET</button>
  <button class="btn btn-success" type="submit" name="btnsimpan">SIMPAN</button>
</form>