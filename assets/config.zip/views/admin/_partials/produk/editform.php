<!--edit produk-->

<form action="" method="POST" enctype="multipart/form-data">
  <div class="form-group col-md-6">
    <label for="inputId_produk">Id Produk</label>
    <input name="txtid_produk" type="text" class="form-control" id="inputId_produk" disabled value="<?php echo $produk->id_produk ?>">
  </div>

  <div class="form-group col-md-6">
    <label for="inputNama">Nama</label>
    <input name="txtnama" type="text" class="form-control" id="inputNama" required value="<?php echo $produk->nama ?>">
  </div>

  <div class="form-row col-md-6">
    <div class="form-group col-md-6">
      <label for="inputKategori">Kategori</label>
      <select name="txtkategori" class="form-control" id="inputKategori">
        <option hidden selected><?php echo $produk->kategori ?></option>
        <option>Battery</option>
        <option>Bearing</option>
        <option>Brake Parts</option>
        <option>Cables</option>
        <option>Chain & Gear</option>
        <option>Cluth</option>
        <option>CVT Parts</option>
        <option>Electric Parts</option>
        <option>Engine Parts</option>
        <option>Gasket</option>
        <option>Other Parts</option>
        <option>Suspension Parts</option>
        <option>Tires</option>
        <option>Wheel Parts</option>
      </select>
    </div>
    <div class="form-group col-md-6">
      <label for="formFoto">Foto</label>
      <input name="txtfoto" type="file" class="form-control-file" id="formFoto" required value="<?php echo $produk->foto ?>">
      <small>Nama file tanpa spasi (contoh : tiresma3dnmaxxis)</small>
    </div>
  </div>

  <div class="form-group col-md-6">
    <label for="textareaAlamat">Keterangan</label>
    <textarea name="txtketerangan" class="form-control" id="textareaAlamat" rows="3"><?php echo $produk->keterangan ?></textarea>
  </div>

  <a class="btn btn-secondary" href="<?php echo site_url('produk/index'); ?>">BATAL</a>
  <button class="btn btn-danger" type="reset">RESET</button>
  <button class="btn btn-success" type="submit" name="btnsimpan">SIMPAN</button>
</form>