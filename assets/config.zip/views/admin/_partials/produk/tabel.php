<table class="table-sm table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">
    <thead>
        <tr>
            <th>Id Produk</th>
            <th>Nama</th>
            <th>Kategori</th>
            <th>Foto</th>
            <th>Keterangan</th>
            <th>Fungsi</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($produk as $s) { ?>
            <tr>
                <td class="" width="10%">
                    <?php echo $s->id_produk ?>
                </td>
                <td class="text-break" width="20%">
                    <?php echo $s->nama ?>
                </td>
                <td class="text-break" width="15%">
                    <?php echo $s->kategori ?>
                </td>
                <td class="text-break" width="15%">
                    <img id="imgFoto" src="<?php echo base_url('upload/produk/' . $s->foto) ?>" width="128" />
                </td>
                <td class="text-break" width="30%">
                    <?php echo $s->keterangan ?>
                </td>
                <td class="" width="20%">
                    <a class="btn btn-warning text-white my-2 col-lg-auto" href="<?php echo site_url('produk/edit/' . $s->id_produk) ?>">Edit</a>

                    <a class="btn btn-danger text-white my-2 col-lg-auto" href="<?php echo site_url('produk/delete/' . $s->id_produk) ?>">Hapus</a>
                </td>
            </tr>
        <?php } ?>

    </tbody>
</table>
<script>
    console.log(encodeURI(imgFoto));
</script>