<!-- Sidebar -->
<nav class="navbar-fixed-top">
	<ul class="nav flex-column" id="">
		<li class="nav-item text-center">
			<span id="date"></span>
			<span id="time"></span>
		</li>
		<li class="nav-item border-bottom sidebar">
			<a class="nav-link" href="<?php echo site_url('main/dashboard') ?>">
				<span class="h4">Dashboard</span>
			</a>
		</li>

		<li class="nav-item">
			<a class="nav-link dropdown-toggle h5 text-decoration-none" href="#collapseProduk" role="button" data-toggle="collapse">
				Produk
			</a>
			<ul class="collapse" id="collapseProduk">
				<li class="nav">
					<a href="<?php echo site_url('produk/tambah') ?>">Tambah</a>
				</li>
				<li class="nav">
					<a href="<?php echo site_url('produk/index') ?>">List</a>
				</li>
			</ul>
		</li>

		<li class="nav-item">
			<a class="nav-link dropdown-toggle h5 text-decoration-none" href="#collapseOutlet" role="button" data-toggle="collapse">
				Outlet
			</a>
			<ul class="collapse" id="collapseOutlet">
				<li class="nav">
					<a href="<?php echo site_url('outlet/tambah') ?>">Tambah</a>
				</li>
				<li class="nav">
					<a href="<?php echo site_url('outlet/index') ?>">List</a>
				</li>
			</ul>
		</li>

		<li class="nav-item">
			<a class="nav-link dropdown-toggle h5 text-decoration-none" href="#collapseAdmin" role="button" data-toggle="collapse" aria-expanded="false" aria-controls="collapseAdmin">
				Admin
			</a>
			<ul class="collapse" id="collapseAdmin">
				<li class="nav">
					<a href="<?php echo site_url('admin/tambah') ?>">TAMBAH</a>
				</li>
				<li class="nav">
					<a href="<?php echo site_url('admin/index') ?>">LIHAT</a>
				</li>
			</ul>
		</li>

		<li class="nav-item">
			<a class="nav-link h5 text-decoration-none" href="<?php echo site_url('admin/logout') ?>">
				Logout
			</a>
	</ul>
</nav>