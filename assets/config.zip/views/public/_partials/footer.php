<!--FOOTER-->
<div class="container-fluid footer">
    <div class="row">
        <div class="col"></div>

        <div class="col-9">
            <div class="row">
                <div class="col">
                    <div class="ft1"><?php echo $pengaturan->judul; ?></div> <br>

                    <div class="ft2"><?php echo $pengaturan->alamat; ?>
                    </div> <br>

                    <div class="ft2">Telp: <?php echo $pengaturan->telp; ?><br>
                        Email: <?php echo $pengaturan->email; ?>
                    </div>
                </div>

                <div class="col"></div>

                <div class="col">
                    <div class="cn">CONNECT WITH US ON SOCIAL MEDIA :</div>

                    <div style="margin-top: 20px; margin-bottom: 20px;">

                        <a href="<?php echo $pengaturan->fb; ?>"><span class="iconify" data-icon="ps:facebook-alt" style="color: white; margin-left: 150px;" data-width="40" data-height="40"></span></a>
                        <a href="<?php echo $pengaturan->ig; ?>"><span class="iconify" data-icon="bi:instagram" style="color: white; margin-left: 40px;" data-width="40" data-height="40"></span></a>
                    </div>

                    <div class="cr">
                        Copyright@2021. All Right Reserved.
                    </div>
                </div>
            </div>
        </div>

        <div class="col"></div>
    </div>
</div>
</div>