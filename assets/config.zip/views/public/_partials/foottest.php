<!--FOOTER-->
<div class="container-fluid footer">
    <div class="row">
        <div class="col"></div>

        <div class="col-9">
            <div class="row">
                <div class="col">
                    <div class="ft1">PT LEGEN SUKSES INVENTIF</div> <br>

                    <div class="ft2">Ruko Mitra Mall Blok H2 No. 04-05 & 08, <br>
                        Bukit Tempayan, Batu Aji, Kota Batam </div> <br>

                    <div class="ft2">Telp: +62 811 700 9316 <br>
                        Email: ptlegensuksesinventif@gmail.com</div>
                </div>

                <div class="col"></div>

                <div class="col">
                    <div class="cn">CONNECT WITH US ON SOCIAL MEDIA :</div>

                    <div style="margin-top: 20px; margin-bottom: 20px;">
                        <a href="<?php echo $pengaturan->fb; ?>"><span class="iconify" data-icon="ps:facebook-alt" style="color: white; margin-left: 150px;" data-width="40" data-height="40"></span></a>
                        <a href="<?php echo $pengaturan->ig; ?>"><span class="iconify" data-icon="bi:instagram" style="color: white; margin-left: 40px;" data-width="40" data-height="40"></span></a>
                    </div>

                    <div class="cr">
                        Copyright@2021. All Right Reserved.
                    </div>
                </div>
            </div>
        </div>

        <div class="col"></div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="https://code.iconify.design/2/2.0.3/iconify.min.js"></script>
</body>

</html>