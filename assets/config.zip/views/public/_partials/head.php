<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS Online -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
    <!-- Custom styles for this template-->
    <link href="<?= base_url('assets/'); ?>frontend/css/aboutus.css" rel="stylesheet">
    <!-- Custom styles for this template minimal version-->
    <!--<link href="<php echo base_url('') ?>" rel="stylesheet">-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="icon" href="<?php echo base_url('assets/frontend/img/' . $pengaturan->favicon) ?>" type="image/gif" sizes="16x16">

    <title>
        <?php echo $title; ?> - <?php echo $pengaturan->judul; ?>
    </title>
</head>