<html>

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS Online -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
    <!-- Custom styles for this template-->
    <link href="<?= base_url(); ?>assets/frontend/css/aboutus.css" rel="stylesheet">
    <!-- Custom styles for this template minimal version-->
    <!--<link href="<php echo base_url('') ?>" rel="stylesheet">-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <title>
        <?php echo $title; ?> - <?php echo $pengaturan->judul; ?>
    </title>

</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
        <a class="navbar-brand" href="<?= site_url('Main/index'); ?>"><span class="iconify" data-icon="icomoon-free:home" style="margin-left: 200px; color: rgb(52, 63, 223);"></span></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link" href="<?= site_url('Main/produk'); ?>">PRODUCTS</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= site_url('Main/about'); ?>">ABOUT US</a>
                </li>
            </ul>
            <a class="nav-link" href="<?php echo $pengaturan->fb; ?>" style="padding-right: 0;"><span class="iconify" data-icon="ps:facebook-alt" style="color: white;" data-width="20" data-height="20"></span></a>
            <a class="nav-link" href="<?php echo $pengaturan->ig; ?>" style="margin-right: 180px;"><span class="iconify" data-icon="bi:instagram" style="color: white;" data-width="20" data-height="20"></span></a>
        </div>
    </nav>