<base href="<?php echo base_url(); ?>">
<!--login outlet-->

<form class="user" method="post" action="<?= site_url('outlet/login'); ?>">
  <div class="form-group">
    <label for="inputTelp">Telp</label>
    <input type="text" class="form-control form-control-user" id="inputTelp" name="txttelp" placeholder="">
  </div>
  <div class="form-group">
    <label for="inputPin">Pin</label>
    <input type="pin" class="form-control form-control-user" id="inputPin" name="txtpin" placeholder="">
  </div>
  <small>Belum punya akun? <span><a href="<?= site_url('outlet/signup'); ?>">Sign Up</a> </span></small>
  <div class="centering">
    <button type="submit" class="login" name="btnlogin">LOGIN</button>
  </div>
</form>