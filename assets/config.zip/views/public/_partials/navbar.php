<base href="<?php echo base_url(); ?>">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <a class="navbar-brand" href="<?php echo site_url('main/index') ?>"><span class="iconify" data-icon="icomoon-free:home" style="margin-left: 200px; color: rgb(52, 63, 223);"></span></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="<?php echo site_url('main/produk') ?>">PRODUCTS</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo site_url('main/about') ?>">ABOUT US</a>
            </li>
        </ul>
        <a class="nav-link" href="<?php echo $pengaturan->fb; ?>" style="padding-right: 0;"><span class="iconify" data-icon="ps:facebook-alt" style="color: white;" data-width="20" data-height="20"></span></a>
        <a class="nav-link" href="<?php echo $pengaturan->ig; ?>" style="margin-right: 180px;"><span class="iconify" data-icon="bi:instagram" style="color: white;" data-width="20" data-height="20"></span></a>
    </div>
</nav>