<!-- signup outlet -->
<form enctype="multipart/form-data" action="" method="POST">
  <div class="form-group">
    <label for="inputNama">Nama Lengkap/Full Name</label>
    <input type="text" class="form-control form-control-user" id="inputNama" name="txtnama" placeholder="">
  </div>

  <div class="form-group">
    <label for="inputOutlet">Outlet</label>
    <input type="text" class="form-control form-control-user" id="inputOutlet" name="txtoutlet" placeholder="">
  </div>

  <div class="form-group">
    <label for="inputTelp">Telp</label>
    <input type="text" class="form-control form-control-user" name="txttelp" id="inputTelp" placeholder="">
  </div>

  <div class="form-group">
    <label for="inputEmail">Email</label>
    <input type="text" class="form-control form-control-user" name="txtemail" id="inputEmail" placeholder="">
  </div>

  <div class="form-group">
    <label for="inputAlamat">Alamat</label>
    <textarea type="text" class="form-control form-control-user" name="txtalamat" id="inputAlamat"></textarea>
  </div>

  <div class="form-group">
    <label for="inputPos">Pos</label>
    <input type="text" class="form-control form-control-user" name="txtpos" id="inputPos" placeholder="">
  </div>

  <div class="form-group">
    <label for="inputPin">Pin</label>
    <input type="password" class="form-control form-control-user" name="txtpin" id="inputPin" placeholder="">
  </div>

  <div class="form-group">
    <label for="inputKonfirm">Konfirmasi Pin</label>
    <input type="password" class="form-control form-control-user" name="txtkonfirm" id="inputKonfirm" placeholder="">
  </div>

  <div class="form-group">
    <label for="inputFoto">Foto</label>
    <input type="file" class="form-control-file" name="txtfoto" id="inputFoto">
  </div>
  <small>Sudah punya akun? <span><a href="<?= site_url('outlet/login'); ?>">Login</a> </span></small>
  <div class="centering">
    <button type="submit" class="register" name="btnsimpan">SIGNUP</button>
  </div>
</form>