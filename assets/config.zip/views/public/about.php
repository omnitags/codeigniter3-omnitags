<base href="<?php echo base_url(); ?>">
<div class="container-fluid">
    <!--Title and Search Box-->
    <div class="container-fluid" style="margin-top: 60px;">
        <div class="row">

            <div class="col-1"></div>

            <div class="col-5 bgw" style="padding-left: 60px; padding-top: 25px;">
                <img src="<?= base_url('assets/frontend/img/' . $pengaturan->logo); ?>" alt="" height="75px">
            </div>

            <div class="col-2 bgw"></div>

            <div class="col-3 bgw">
                <form class="form-inline" style="padding-top: 25px;">
                    <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" style="border-radius: 20px;">
                    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
                </form>
            </div>

            <div class="col"></div>
        </div>
    </div>
    <div class="row">
        <div class="col"></div>

        <div class="col-9" style="min-height:500px;">
            <div class="row">
                <div class="col-md pt-md-5 mb-md-3 border-bottom">
                    <div class="row">
                        <div class="col-md-auto my-auto">
                            <span class="h1"><?php echo $header1; ?></span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-7">
                    <img src="<?php echo base_url() ?>assets/frontend/img/toko.jpg" alt="" style="width: 95%; margin-left: 70px;">
                </div>

                <div class="col-3">
                    <img src="<?php echo base_url() ?>assets/frontend/img/gudang.jpg" alt="" style="width: 98%; margin-left: 60px;">
                </div>

                <div class="col"></div>
            </div>

            <!--PROFIL & PROFILE-->
            <div class="row">
                <div class="col-6">
                    <div class="t8">Profil</div>
                    <div class="t6">
                        &emsp; &emsp; PT LEGEN SUKSES INVENTIF mulai berdiri sejak tahun 2018 dan bergerak dalam
                        bidang usaha
                        distribusi suku cadang sepeda motor, yang mana sebelum berbadan hukum perseroan terbatas
                        adalah berbentuk toko spare part dengan nama SUNLI MOTOR. SUNLI MOTOR sendiri didirikan
                        oleh BAPAK SUNTALY (KOMISARIS PT LSI) dan BAPAK JUANDA JUNAIDI (DIREKTUR PT LSI) pada
                        tahun 2005 yang mana awal mulanya hanya memiliki 2 orang karyawan. <br>
                        <br>
                        &emsp; &emsp; Saat ini PT LSI sendiri telah berkembang menjadi salah satu distributor
                        spare part
                        khususnya untuk kendaraan roda dua (2W) di Batam dan Kepulauan Riau. Dengan jumlah
                        karwayan mencapai 20 orang saat ini, PT LSI bermaksud untuk semakin mengembangkan diri
                        dengan menambahkan produk baru sebagai bagian dari peningkatan penjualan yang
                        berkesinambungan.
                    </div>
                </div>

                <div class="col-6">
                    <div class="t8">Profile</div>
                    <div class="t7">
                        &emsp; &emsp; PT LEGEN SUKSES INVENTIF was established in 2018 and is engaged in the
                        distribution of
                        motorcycle parts, which before being incorporated as a limited liability company was in
                        the form of a spare part shop under the name SUNLI MOTOR.
                        SUNLI MOTOR itself was founded by Mr. SUNTALLY (COMMISSIONER OF PT LSI) and Mr. JUANDA
                        JUNAIDI (DIRECTOR OF PT LSI) in 2005 which initially only had 2 employees. <br>
                        <br>
                        &emsp; &emsp; Currently PT LSI itself has developed into a distributor of spare parts,
                        especially for
                        two-wheeled vehicles (2W) in Batam and Riau Islands. With currently 20 employees, PT LSI
                        intends to further develop itself by adding new products as part of a continuous
                        increase in sales.
                    </div>
                </div>

                <div class="col-1"></div>
            </div>
        </div>

        <div class="col"></div>
    </div>
</div>

<!--VISI & MISI-->
<div class="container-fluid">
    <div class="row">
        <div class="col"></div>

        <div class="col-9 bg2">
            <div class="row">
                <div class="col-6">
                    <div class="t2">Visi</div>
                    <div class="t3">
                        <span class="iconify" data-icon="bx:bxs-circle" style="color: white;" data-width="10" data-height="10"></span> &nbsp;
                        Menjadi salah satu perusahaan distribusi terbesar dan terbaik, dan ikut memajukan dan
                        mengembangkan perekonomian di kawasan Kepulauan Riau
                    </div>

                    <div style="padding-top: 50px;"></div>

                    <div class="t2">Misi</div>
                    <div class="t3">
                        <span class="iconify" data-icon="bx:bxs-circle" style="color: white;" data-width="10" data-height="10"></span> &nbsp;
                        Peningkatan taraf hidup dan perekonomian seluruh elemen perusahaan dan juga
                        masyarakat sekitar perusahaan
                    </div>
                    <div class="t3">
                        <span class="iconify" data-icon="bx:bxs-circle" style="color: white;" data-width="10" data-height="10"></span> &nbsp;
                        Serta menjadi salah satu perusahaan distribusi suku cadang kendaraan sebagai bagian
                        dari penggerak roda perekonomian di mana perusahaan berada
                    </div>
                </div>

                <div class="col-6">
                    <div class="t5">Vision</div>
                    <div class="t4">
                        <span class="iconify" data-icon="bx:bxs-circle" style="color: white;" data-width="10" data-height="10"></span> &nbsp;
                        To become one of the largest and best distribution companies, and participate in
                        advancing and developing the economy in the Riau Islands region
                    </div>

                    <div style="padding-top: 20px;"></div>

                    <div class="t5">Mission</div>
                    <div class="t4">
                        <span class="iconify" data-icon="bx:bxs-circle" style="color: white;" data-width="10" data-height="10"></span> &nbsp;
                        Improving the standard of living and the economy of all elements of the company and also
                        the community around the company
                    </div>
                    <div class="t4">
                        <span class="iconify" data-icon="bx:bxs-circle" style="color: white;" data-width="10" data-height="10"></span> &nbsp;
                        As well as being one of the vehicle parts distribution companies as part of the driving
                        wheel of the economy where the company is located
                    </div>
                </div>
            </div>
        </div>

        <div class="col"></div>
    </div>

</div>
</div>