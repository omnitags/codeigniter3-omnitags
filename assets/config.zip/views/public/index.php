<!DOCTYPE html>
<html lang="en">

<body>

	<base href="<?php echo base_url(); ?>">
	<div class="bg1 mt-5">
		<!--Title and Search Box-->
		<div class="container-fluid" style="margin-top: 60px;">
			<div class="row">

				<div class="col-1"></div>

				<div class="col-5 bgw" style="padding-left: 60px; padding-top: 25px;">
					<img src="<?= base_url('assets/frontend/img/' . $pengaturan->logo); ?>" alt="" height="75px">
				</div>

				<div class="col-2 bgw"></div>

				<div class="col-3 bgw">
					<form class="form-inline" style="padding-top: 25px;">
						<input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" style="border-radius: 20px;">
						<button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
					</form>
				</div>

				<div class="col"></div>
			</div>
		</div>

		<!--Carousel-->
		<div class="container-fluid">
			<div class="row">
				<div class="col"></div>

				<div class="col-9" style="padding-left: 0; padding-right: 0;">
					<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
						<ol class="carousel-indicators">
							<li data-target="#carouselExampleIndicators" data-slide-to="0" class="active" style="width: 10%; height: 10px; margin-right: 10px;"></li>
							<li data-target="#carouselExampleIndicators" data-slide-to="1" style="width: 10%; height: 10px;"></li>
							<li data-target="#carouselExampleIndicators" data-slide-to="2" style="width: 10%; height: 10px; margin-left: 10px;"></li>
						</ol>
						<div class="carousel-inner">

							<div class="carousel-item active">
								<img class="d-block w-100" src="assets/images/headline/slider/F1.png" alt="First slide" style="height: 525px;">
							</div>
							<div class="carousel-item">
								<img class="d-block w-100" src="assets/images/headline/slider/F3.png" alt="Second slide" style="height: 525px;">
							</div>
							<div class="carousel-item">
								<img class="d-block w-100" src="assets/images/headline/slider/F4.png" alt="Third slide" style="height: 525px;">
							</div>
						</div>
						<a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
							<span class="carousel-control-prev-icon carcon" aria-hidden="true"></span>
							<span class="sr-only">Previous</span>
						</a>
						<a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
							<span class="carousel-control-next-icon" aria-hidden="true"></span>
							<span class="sr-only">Next</span>
						</a>
					</div>
				</div>

				<div class="col"></div>
			</div>
		</div>

		<!--PRODUCTS-->
		<div class="container-fluid">
			<div class="row">
				<div class="col">

				</div>

				<div class="col-9" style="min-height:500px; background-color: whitesmoke;">
					<p style="text-align: center; font-size: 30pt; margin-top: 30px;">PRODUCTS</p>
					<div class="row list-inline">
						<?php foreach ($produk as $s) { ?>
							<div class="col-md-auto my-2">
								<div class="card" style="width: 18rem;">
									<div class="card-header">
										<h5>
											<?php echo $s->nama ?>
										</h5>
									</div>
									<img src="<?= base_url('upload/produk/' . $s->foto) ?>" alt="..." class="card-img img-thumbnail Prod_img1">
									<div class="card-body">
										<span>
											<?php echo $s->kategori ?>
										</span><br>
										<a class="btn btn-primary" href="<?php echo site_url('main/detail/' . $s->id_produk) ?>">Lihat</a>
									</div>
								</div>
							</div>
						<?php } ?>
					</div>

				</div>

				<div class="col">

				</div>
			</div>
		</div>

		<?php $this->load->view('public/_partials/footer'); ?>
	</div>



	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
	<script src="https://code.iconify.design/2/2.0.3/iconify.min.js"></script>
</body>

</html>