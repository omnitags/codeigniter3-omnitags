<!DOCTYPE html>
<html lang="en">

<body>
	<div class="container-fluid">
		<!--Title and Search Box-->
		<div class="container-fluid" style="margin-top: 60px;">
			<div class="row">

				<div class="col-1"></div>

				<div class="col-5 bgw" style="padding-left: 60px; padding-top: 25px;">
					<img src="<?= base_url('assets/frontend/img/' . $pengaturan->logo); ?>" alt="" height="75px">
				</div>

				<div class="col-2 bgw"></div>

				<div class="col-3 bgw">
					<form class="form-inline" style="padding-top: 25px;">
						<input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" style="border-radius: 20px;">
						<button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
					</form>
				</div>

				<div class="col"></div>
			</div>
		</div>
		<div class="row">
			<div class="col"></div>
			<div class="col-9" style="min-height: 500px;">
				<div class="row">
					<div class="col-md pt-md-5 mb-md-3 border-bottom">
						<div class="row">
							<div class="col-md-auto my-auto">
								<span class="h1"><?php echo $header1; ?></span>
							</div>
						</div>
					</div>
				</div>

				<div class="centering">
					<button class="whatsapp" name="btnwa"><a style="text-decoration:none; color:white" href="https://api.whatsapp.com/send? phone=6285765601934">WHATSAPP</a></button>
				</div>

				<div class="centering">
					<button class="messenger" name="btnms">
						MESSENGER
					</button>
				</div>

				<div class="centering">
					<button class="instagram" name="btnig">
						INSTAGRAM
					</button>
				</div>


			</div>

			<div class="col"></div>
		</div>
	</div>
	<?php $this->load->view('public/_partials/footer'); ?>

	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
	<script src="https://code.iconify.design/2/2.0.3/iconify.min.js"></script>
</body>

</html>