<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<title>Document</title>

	<link rel="stylesheet" href="templ.css" />

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous" />
	<link rel="preconnect" href="https://fonts.googleapis.com" />
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
</head>

<body>
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
		<a class="navbar-brand" href="Home.html"><span class="iconify" data-icon="icomoon-free:home" style="margin-left: 200px; color: rgb(52, 63, 223)"></span></a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>

		<div class="collapse navbar-collapse" id="navbarSupportedContent">
			<ul class="navbar-nav mr-auto">
				<li class="nav-item">
					<a class="nav-link" href="Products.html">PRODUCTS</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="PhotosVideos.html">PHOTOS & VIDEOS</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="AboutUs.html">ABOUT US</a>
				</li>
			</ul>
			<a class="nav-link" href="#" style="padding-right: 0"><span class="iconify" data-icon="ps:facebook-alt" style="color: white" data-width="20" data-height="20"></span>
			</a>
			<a class="nav-link" href="#" style="margin-right: 180px"><span class="iconify" data-icon="bi:instagram" style="color: white" data-width="20" data-height="20"></span>
			</a>
		</div>
	</nav>

	<div class="bg1">
		<div class="container-fluid" style="margin-top: 60px">
			<div class="row">
				<div class="col"></div>

				<div class="col-3 bgw" style="padding-left: 50px; padding-top: 25px">
					<img src="assets/images/lsi.png" alt="" />
					<div class="pt">
						PT LEGEN <br />
						SUKSES INVENTIF
					</div>
				</div>

				<div class="col-3 bgw"></div>

				<div class="col-3 bgw">
					<div class="sbox">
						<input type="text" class="input" placeholder="Search..." style="
									border: none;
									background-color: rgb(201, 201, 201);
									border-radius: 10px;
									outline: none;
								" />
						<div class="btn btn-light">
							<span class="iconify" data-icon="bx:bx-search-alt-2"></span>
						</div>
					</div>
				</div>

				<div class="col"></div>
			</div>
		</div>

		<div class="container-fluid">
			<div class="row">
				<div class="col"></div>

				<div class="col-9 bgw1 bord">
					<div class="row">
						<div class="col">
							<!--Edit di sini-->
						</div>
					</div>
				</div>

				<div class="col"></div>
			</div>
		</div>

		<!--FOOTER-->
		<div class="container-fluid footer">
			<div class="row">
				<div class="col"></div>

				<div class="col-9">
					<div class="row">
						<div class="col">
							<div class="ft1">PT LEGEN SUKSES INVENTIF</div>
							<br />

							<div class="ft2">
								Ruko Mitra Mall Blok H2 No. 04-05 & 08, <br />
								Bukit Tempayan, Batu Aji, Kota Batam
							</div>
							<br />

							<div class="ft2">
								Telp: +62 811 700 9316 <br />
								Email: ptlegensuksesinventif@gmail.com
							</div>
						</div>

						<div class="col"></div>

						<div class="col">
							<div class="cn">CONNECT WITH US ON SOCIAL MEDIA :</div>

							<div style="margin-top: 20px; margin-bottom: 20px">
								<span class="iconify" data-icon="ps:facebook-alt" style="color: white; margin-left: 230px" data-width="40" data-height="40"></span>
								<span class="iconify" data-icon="bi:instagram" style="color: white; margin-left: 40px" data-width="40" data-height="40"></span>
							</div>

							<div class="cr">Copyright@2021. All Right Reserved.</div>
						</div>
					</div>
				</div>

				<div class="col"></div>
			</div>
		</div>
	</div>

	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
	<script src="https://code.iconify.design/2/2.0.3/iconify.min.js"></script>
</body>

</html>