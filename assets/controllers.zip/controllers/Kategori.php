<?php
class Kategori extends CI_Controller
{

  public function index()
  {
    $kategori = array(
      'title' => "Data Kategori",
      'konten' => "v_kategori",
      'kategori' => $this->ktg->ambildata('kategori')->result(),
    );
    $this->load->view('dashboard', $kategori);
  }

  public function tambah()
  {
    $data = array(
      'id_kategori' => "",
      'kategori' => $this->input->post('kategori'),
    );
    $simpan = $this->ktg->simpan($data);

    if ($simpan) {
      $this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i> Data tersimpans</span>');
      $this->session->set_flashdata('pangggil', '$(".toast").toast("show")');
    } else {
      $this->session->set_flashdata('pesan', 'Data gagal tersimpan');
      $this->session->set_flashdata('pangil', '$(".toast").toast("show")');
    }

    redirect(site_url('Kategori'));
  }

  public function update()
  {
    //update kategori set $data from kategori where $where

    $where = array('id_kategori' => $this->input->post('id_kategori'));
    $data = array(
      'kategori' => $this->input->post('kategori'),
    );

    $simpan = $this->ktg->ubah($data, $where);

    //notifikasi
    if ($simpan) {
      $this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i> Data terubah</span>');
      $this->session->set_flashdata('panggil', '$(".toast").toast("show")');
    } else {
      $this->session->set_flashdata('pesan', 'Data gagal terupdate');
      $this->session->set_flashdata('panggil', '$(".toast").toast("show")');
    }

    redirect(site_url('Kategori'));
  }

  public function hapus($kd)
  {
    //delete from kategori $where
    $where = array("id_kategori" => $kd);

    $hapus = $this->ktg->hapus($where);

    //notifikasi
    if ($hapus) {
      $this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i> Data terhapus</span>');
      $this->session->set_flashdata('panggil', '$(".toast").toast("show")');
    } else {
      $this->session->set_flashdata('pesan', 'Data gagal terhapus');
      $this->session->set_flashdata('panggil', '$(".toast").toast("show")');
    }

    redirect(site_url('Kategori'));
  }
}
