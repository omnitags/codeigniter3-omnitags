<?php
class Kelas extends CI_Controller
{

	public function index()
	{
		$data = array(
			'title' => "Data Kelas",
			'konten' => "v_kelas",
			'kelas' => $this->kls->ambildata('kelas')->result()
		);
		$this->load->view('dashboard', $data);
	}

	public function tambah()
	{
		$config['upload_path'] = './assets/upload/';
		$config['allowed_types'] = 'jpg|jpeg|png|gif|svg|webp';

		//panggil fungsi untuk upload
		$this->load->library('upload', $config);

		//ambil into nama dan ukuran gambar
		$gambar = $_FILES['foto_kelas']['name'];
		$ukuran = $_FILES['foto_kelas']['size'];

		if ($ukuran > 0) {
			$this->upload->do_upload("foto_kelas");
		}

		$data = array(
			'id' => "",
			'nama' => $this->input->post('nama'),
			'jurusan' => $this->input->post('jurusan'),
			'description' => $this->input->post('description'),
			'foto_kelas' => $gambar
		);
		$simpan = $this->kls->simpan($data);

		if ($simpan) {
			$this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i> Data tersimpan</span>');
			$this->session->set_flashdata('pangggil', '$(".toast").toast("show")');
		} else {
			$this->session->set_flashdata('pesan', 'Data gagal tersimpan');
			$this->session->set_flashdata('pangil', '$(".toast").toast("show")');
		}

		redirect(site_url('Kelas'));
	}

	public function update()
	{
		//update kelas set $data from kelas where $where

		$config['upload_path'] = './assets/upload/';
		$config['allowed_types'] = 'jpg|jpeg|png|gif|webp';

		//panggil fungsi untuk upload
		$this->load->library('upload', $config);

		//ambil into nama dan ukuran gambar
		$gambar = $_FILES['foto_kelas']['name'];

		if ($gambar) {
			$this->upload->do_upload("foto_kelas");
		} else {
			$gambar = $this->input->post("txtfoto");
		}

		$where = array('id' => $this->input->post('id'));
		$data = array(
			'nama' => $this->input->post('nama'),
			'jurusan' => $this->input->post('jurusan'),
			'description' => $this->input->post('description'),
			'foto_kelas' => $gambar
		);

		$simpan = $this->kls->ubah($data, $where);

		//notifikasi
		if ($simpan) {
			$this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i> Data terubah</span>');
			$this->session->set_flashdata('panggil', '$(".toast").toast("show")');
		} else {
			$this->session->set_flashdata('pesan', 'Data gagal terupdate');
			$this->session->set_flashdata('panggil', '$(".toast").toast("show")');
		}

		redirect(site_url('Kelas'));
	}

	public function hapus($kd)
	{
		//delete from kelas $where
		$where = array("id" => $kd);

		$hapus = $this->kls->hapus($where);

		//notifikasi
		if ($hapus) {
			$this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i> Data terhapus</span>');
			$this->session->set_flashdata('panggil', '$(".toast").toast("show")');
		} else {
			$this->session->set_flashdata('pesan', 'Data gagal terhapus');
			$this->session->set_flashdata('panggil', '$(".toast").toast("show")');
		}

		redirect(site_url('Kelas'));
	}
}
