<?php
class Kenangan extends CI_Controller
{

    public function index()
    {
        $data = array(
            'title' => "Data Kenangan",
            'konten' => "v_kenangan",
            'kelas' => $this->kls->ambildata()->result(),
            'kategori' => $this->ktg->ambildata()->result(),
            'kenangan' => $this->kng->ambildata()->result()
        );
        $this->load->view("dashboard", $data);
    }

    public function tambah()
    {
        $config['upload_path'] = './assets/upload/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif|svg|webp';

        //panggil fungsi untuk upload
        $this->load->library('upload', $config);

        //ambil into nama dan ukuran gambar
        $gambar = $_FILES['foto']['name'];
        $ukuran = $_FILES['foto']['size'];

        if ($ukuran) {
            $this->upload->do_upload("foto");
        }

        $data = array(
            'id_kenangan' => "",
            'id' => $this->input->post("id"),
            'foto' => $gambar,
            'kategori' => $this->input->post("kategori")
        );
        $simpan = $this->kng->simpan($data, 'kenangan');

        if ($simpan) {
            $this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i> Kenangan berhasil dilaporkan</span>');
            $this->session->set_flashdata('pangggil', '$(".toast").toast("show")');
        } else {
            $this->session->set_flashdata('pesan', 'Kenangan gagal dilaporkan');
            $this->session->set_flashdata('pangil', '$(".toast").toast("show")');
        }

        redirect(site_url('Kenangan'));
    }

    public function update()
    {
        //update kenangan set $data from kenangan where $where
        $config['upload_path'] = './assets/upload/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif|svg|webp';

        //panggil fungsi untuk upload
        $this->load->library('upload', $config);

        //ambil into nama dan ukuran gambar
        $gambar = $_FILES['foto']['name'];

        if ($gambar) {
            $this->upload->do_upload("foto");
        } else {
            $gambar = $this->input->post("txtfoto");
        }

        $where = array('id_kenangan' => $this->input->post('id_kenangan'));
        $data = array(
            'id' => $this->input->post("id"),
            'foto' => $gambar,
            'kategori' => $this->input->post("kategori")
        );

        $simpan = $this->kng->ubah($data, $where);

        //notifikasi
        if ($simpan) {
            $this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i> Data terubah</span>');
            $this->session->set_flashdata('panggil', '$(".toast").toast("show")');
        } else {
            $this->session->set_flashdata('pesan', 'Data gagal terupdate');
            $this->session->set_flashdata('panggil', '$(".toast").toast("show")');
        }

        redirect(site_url('Kenangan'));
    }

    public function hapus($kd)
    {
        //delete from kenangan $where
        $where = array("id_kenangan" => $kd);

        $hapus = $this->kng->hapus($where);

        //notifikasi
        if ($hapus) {
            $this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i> Data terhapus</span>');
            $this->session->set_flashdata('panggil', '$(".toast").toast("show")');
        } else {
            $this->session->set_flashdata('pesan', 'Data gagal terhapus');
            $this->session->set_flashdata('panggil', '$(".toast").toast("show")');
        }

        redirect(site_url('Kenangan'));
    }
}
