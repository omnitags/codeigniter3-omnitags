<?php
class Pesan extends CI_Controller
{

    public function index()
    {
        $data = array(
            'title' => "Data Pesan",
            'konten' => "v_pesan",
            'kelas' => $this->kls->ambildata()->result(),
            'pesan' => $this->psn->ambildata()->result()
        );
        $this->load->view("dashboard", $data);
    }

    public function tambah()
    {
        $data = array(
            'id_pesan' => "",
            'id' => $this->input->post("id"),
            'id_user' => $this->input->post("id_user"),
            'pesan' => $this->input->post("pesan")
        );
        $simpan = $this->psn->simpan($data, 'pesan');

        if ($simpan) {
            $this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i> Pesan berhasil dilaporkan</span>');
            $this->session->set_flashdata('pangggil', '$(".toast").toast("show")');
        } else {
            $this->session->set_flashdata('pesan', 'Pesan gagal dilaporkan');
            $this->session->set_flashdata('pangil', '$(".toast").toast("show")');
        }

        redirect(site_url('Pesan'));
    }

    public function update()
    {
        //update pesan set $data from pesan where $where

        $where = array('id_pesan' => $this->input->post('id_pesan'));
        $data = array(
            'id' => $this->input->post("id"),
            'pesan' => $this->input->post("pesan")
        );

        $simpan = $this->psn->ubah($data, $where);

        //notifikasi
        if ($simpan) {
            $this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i> Data terubah</span>');
            $this->session->set_flashdata('panggil', '$(".toast").toast("show")');
        } else {
            $this->session->set_flashdata('pesan', 'Data gagal terupdate');
            $this->session->set_flashdata('panggil', '$(".toast").toast("show")');
        }

        redirect(site_url('Pesan'));
    }

    public function hapus($kd)
    {
        //delete from pesan $where
        $where = array("id_pesan" => $kd);

        $hapus = $this->psn->hapus($where);

        //notifikasi
        if ($hapus) {
            $this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i> Data terhapus</span>');
            $this->session->set_flashdata('panggil', '$(".toast").toast("show")');
        } else {
            $this->session->set_flashdata('pesan', 'Data gagal terhapus');
            $this->session->set_flashdata('panggil', '$(".toast").toast("show")');
        }

        redirect(site_url('Pesan'));
    }
}
