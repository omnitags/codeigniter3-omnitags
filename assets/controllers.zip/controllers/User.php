<?php
class User extends CI_Controller
{

	public function index()
	{
		$data = array(
			'title' => "Data User",
			'konten' => "v_user",
			'kelas' => $this->kls->ambildata()->result(),
			'user' => $this->usr->ambildata()->result()
		);
		$this->load->view('dashboard', $data);
	}

	public function tambah()
	{
		$config['upload_path'] = './assets/upload/';
		$config['allowed_types'] = 'jpg|jpeg|png|gif|svg|webp';

		//panggil fungsi untuk upload
		$this->load->library('upload', $config);

		//ambil into nama dan ukuran gambar
		$gambar = $_FILES['foto']['name'];
		$ukuran = $_FILES['foto']['size'];

		if ($gambar) {
			$this->upload->do_upload("foto");
		}

		$data = array(
			'id_user' => "",
			'id' => $this->input->post("id"),
			'nama_user' => $this->input->post('nama'),
			'username' => $this->input->post('uname'),
			'password' => $this->input->post('pass'),
			'level' => $this->input->post('level'),
			'foto' => $gambar,
			'hp' => $this->input->post('hp'),
			'email' => $this->input->post('email')

		);
		$simpan = $this->usr->simpan($data);

		if ($simpan) {
			$this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i> Data tersimpan</span>');
			$this->session->set_flashdata('pangggil', '$(".toast").toast("show")');
		} else {
			$this->session->set_flashdata('pesan', 'Data gagal tersimpan');
			$this->session->set_flashdata('pangil', '$(".toast").toast("show")');
		}

		redirect(site_url('User'));
	}

	public function update()
	{
		//update user set $data from user where $where

		$config['upload_path'] = './assets/upload/';
		$config['allowed_types'] = 'jpg|jpeg|png|gif|svg|webp';

		//panggil fungsi untuk upload
		$this->load->library('upload', $config);

		//ambil into nama dan ukuran gambar
		$gambar = $_FILES['foto']['name'];
		$ukuran = $_FILES['foto']['size'];

		if ($gambar) {
			$this->upload->do_upload("foto");
		} else {
			$gambar = $this->input->post("txtfoto");
		}

		$where = array('id_user' => $this->input->post('id'));
		$data = array(
			'id' => $this->input->post("id"),
			'nama_user' => $this->input->post('nama'),
			'username' => $this->input->post('uname'),
			'password' => $this->input->post('pass'),
			'level' => $this->input->post('level'),
			'foto' => $gambar,
			'hp' => $this->input->post('hp'),
			'email' => $this->input->post('email')
		);

		$simpan = $this->usr->ubah($data, $where);

		//notifikasi
		if ($simpan) {
			$this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i> Data terubah</span>');
			$this->session->set_flashdata('panggil', '$(".toast").toast("show")');
		} else {
			$this->session->set_flashdata('pesan', 'Data gagal terupdate');
			$this->session->set_flashdata('panggil', '$(".toast").toast("show")');
		}

		redirect(site_url('User'));
	}

	public function hapus($kd)
	{
		//delete from user $where
		$where = array("id_user" => $kd);

		$hapus = $this->usr->hapus($where);

		//notifikasi
		if ($hapus) {
			$this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i> Data terhapus</span>');
			$this->session->set_flashdata('panggil', '$(".toast").toast("show")');
		} else {
			$this->session->set_flashdata('pesan', 'Data gagal terhapus');
			$this->session->set_flashdata('panggil', '$(".toast").toast("show")');
		}

		redirect(site_url('User'));
	}

	public function logout()
	{
		session_destroy();
		redirect('Welcome');
	}
}
