<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Welcome extends CI_Controller
{

	public function index()
	{
		$data = array(
			'title' => "Perpisahan Kelas",
			'konten' => "v_home"
		);
		$this->load->view('login', $data);
	}

	public function home()
	{
		$data = array(
			'title' => "Pilih Kelas",
			'konten' => "v_home",
			'kelas' => $this->kls->ambildata('kelas')->result()
		);
		$this->load->view('dashboard', $data);
	}

	public function ceklogin()
	{
		$username = $this->input->post('uname');
		$password = $this->input->post('pass');
		$login = $this->usr->ceklogin($username, $password, "user");

		if ($login->num_rows() > 0) {
			$user = $login->result();

			//print_r($user);
			$id_user = $user[0]->id_user;
			$nama = $user[0]->nama_user;
			$level = $user[0]->level;
			$foto = $user[0]->foto;

			//buat session
			$this->session->set_userdata("id_user", $id_user);
			$this->session->set_userdata("nama", $nama);
			$this->session->set_userdata("akses", $level);
			$this->session->set_userdata("foto", $foto);

			$this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i>Login Berhasil</span>');
			$this->session->set_flashdata('panggil', '$(".toast").toast("show")');

			redirect('welcome/home');
		} else {
			$this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i>Login Gagal</span>');
			$this->session->set_flashdata('panggil', '$(".toast").toast("show")');

			redirect('ceklogin');
		}
	}

	public function result($input = null)
	{
		$input = $this->input->post('txtid');
		$id = $this->kls->ambil($input);
		$data = array(
			'title' => 'Perpisahan Kelas',
			'kelas' => $id,
			'kenangan' => $this->kng->join2table($id[0]->id)->result(),
			'kategori' => $this->ktg->ambildata()->result(),
			'pesan' => $this->psn->join2table($id[0]->id)->result()
		);
		if (isset($_POST['btnsimpan'])) {
			$this->load->view("perpisahan.php", $data);
		} elseif (isset($_POST['btncetak'])) {
			$mpdf = new \Mpdf\Mpdf();
			ob_start();
			$html = $this->load->view('perpisahan.php', $data);;
			$html = ob_get_contents();
			ob_end_clean();
			$mpdf->WriteHTML($html);
			$mpdf->Output();
		}
	}

	public function resume()
	{
		$this->load->view('resume.html');
	}

	public function logout()
	{
		session_destroy();

		//buat session
		$this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i>Sesi anda telah berakhir</span>');
		$this->session->set_flashdata('panggil', '$(".toast").toast("show")');
		redirect(site_url("welcome"));
	}
}
