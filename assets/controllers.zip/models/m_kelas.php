<?php
class m_kelas extends CI_Model
{
  private $tabel = 'kelas';

  public function ambildata()
  {
    return $this->db->get($this->tabel);
  }

  public function ambil($input)
  {
    //select * from $tabel where id = $id
    return $this->db->get_where($this->tabel, ["id" => $input])->result();
  }

  public function simpan($data)
  {
    return $this->db->insert($this->tabel, $data);
  }

  public function ubah($data, $where)
  {
    return $this->db->update($this->tabel, $data, $where);
  }

  public function hapus($where)
  {
    return $this->db->delete($this->tabel, $where);
  }
}
