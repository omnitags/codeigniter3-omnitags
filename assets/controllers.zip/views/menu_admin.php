<a href="<?= site_url("welcome/home") ?>">Home</a>
<a href="<?= site_url('kelas'); ?>">Kelas</a>

<a class="h5">Informasi Perpisahan</a>
<a href="<?= site_url('kenangan'); ?>">Kenangan</a>
<a href="<?= site_url('pesan'); ?>">Pesan</a>

<a class="h5">Miscelaneus</a>
<a href="<?= site_url('icon'); ?>">Icon</a>
<a href="<?= site_url('kategori'); ?>">Kategori</a>
<a href="<?= site_url('user'); ?>">Data User</a>

<a href="<?= site_url("welcome/logout") ?>">Logout</a>