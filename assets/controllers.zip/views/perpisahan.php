<base href="<?php echo base_url(); ?>">

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!--=============== FAVICON ===============-->
  <link rel="shortcut icon" href="assets/img/favicon.png" type="image/x-icon">

  <!--=============== SWIPER CSS ===============-->
  <link rel="stylesheet" href="assets/css/swiper-bundle.min.css">

  <!--=============== BOXICONS ===============-->
  <link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'>

  <!--=============== FONTAWESOME ===============-->
  <link rel="stylesheet" href="assets/fontawesome/css/all.css">

  <!--=============== CSS ===============-->
  <link rel="stylesheet" href="assets/css/styles.css">

  <title>Perpisahan Kelas</title>

</head>

<body>

  <!-- Header Section -->
  <section class="header">
    <div class="container text-center">
      <div class="user-box">
        <?php
        if (!$kelas) {
          echo "<tr><td colspan='5' class='text-center'>tidak ada data tersedia</td></tr>";
        } else {
          foreach ($kelas as $k) {
        ?>
            <img src="<?= 'assets/upload/' . $k->foto_kelas; ?>" alt="">
            <h1><?= $k->nama; ?></h1>
            <p><?= $k->jurusan; ?></p>
        <?php }
        } ?>
      </div>

    </div>
    <div class="scroll-btn">
      <div class="scroll-bar">
        <a href="#about"><span> </span></a>
      </div>
    </div>

  </section>

  <!-- User Info Section -->
  <!--=============== HEADER ===============-->
  <header id="header">
    <nav class="nav container">
      <a href="" class="nav__logo">SUDAH 0 TAHUN SEJAK KELULUSAN KAMI</a>

      <!-- Theme change button -->
      <i class="bx bx-moon change-theme" id="theme-button"></i>
    </nav>
  </header>

  <!--=============== MAIN ===============-->
  <main class="main">

    <!--=============== WORK ===============-->
    <section class="work section" id="work">
      <span class="section__subtitle">Galeri Kelas</span>
      <h2 class="section__title">Kenangan Selama Ini</h2>

      <div class="work__filters">
        <span class="work__item active-work" data-filter='all'>Semua</span>
        <?php
        foreach ($kategori as $i) {
        ?>
          <span class="work__item" data-filter='.<?= $i->kategori; ?>'><?= $i->kategori; ?></span>
        <?php }
        ?>
      </div>

      <div class="work__container container grid">
        <?php
        foreach ($kenangan as $n) {
        ?>

          <div class="work__card mix <?= $n->kategori; ?>">
            <img src="<?= 'assets/upload/' . $n->foto; ?>" alt="" class="work__img">

          </div>

        <?php }
        ?>

      </div>




      </div>
    </section>

    <!--=============== TESTIMONIALS ===============-->
    <section class="testimonial section" id="testimonial">
      <span class="section__subtitle">Pesan Kelas</span>
      <h2 class="section__title">Pesan Tuk Kelas</h2>

      <div class="testimonial__container container swiper">
        <div class="swiper-wrapper">
          <?php
          if (!$pesan) {
            echo "<tr><td colspan='5' class='text-center'>tidak ada data tersedia</td></tr>";
          } else {
            foreach ($pesan as $p) {
          ?>

              <div class="testimonial__card swiper-slide">

                <img src="<?= 'assets/upload/' . $p->foto; ?>" alt="" class="testimonial__img">
                <h3 class="testimonial__name"><?= $p->username; ?></h3>
                <p class="testimonial__description">
                  <?= $p->pesan; ?>
                </p>
              </div>
          <?php }
          } ?>
        </div>

        <div class="swiper-pagination"></div>
      </div>
    </section>

    <!--=============== FOOTER ===============-->
    <footer class="footer">
      <div class="footer__container container">
        <?php
        if (!$kelas) {
          echo "<tr>
          <td colspan='5' class='text-center'>tidak ada data tersedia</td>
        </tr>";
        } else {
          foreach ($kelas as $k) {
        ?>
            <h1 class="footer__title">KELAS XII</h1>
        <?php }
        } ?>

        <span class="footer__copy">
          Dibuat dengan <i class="bx bx-heart"></i> dari KHENJY JOHNELSON
        </span>
      </div>
    </footer>
  </main>

  <!--=============== SCROLLREVEAL ===============-->
  <script src="assets/js/scrollreveal.min.js"></script>

  <!--=============== SWIPER JS ===============-->
  <script src="assets/js/swiper-bundle.min.js"></script>

  <!--=============== MIXITUP FILTER ===============-->
  <script src="assets/js/mixitup.min.js"></script>

  <!--=============== MAIN JS ===============-->
  <script src="assets/js/main.js"></script>

</body>

</html>