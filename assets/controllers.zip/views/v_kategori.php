<div class="col-12">
    <button class="btn btn-primary" data-toggle="modal" data-target="#tambah">
        <i class="fa fa-plus"></i> Add Data</button>
</div>
<div class="col-12 scoll">
    <table class="table table-sm table-hover mt-3" id="data">
        <thead>
            <tr>
                <th>Id Kategori</th>
                <th>Nama Kategori</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (!$kategori) {
                echo "<tr><td colspan='5' class='text-center'>tidak ada data tersedia</td></tr>";
            }
            foreach ($kategori as $k) :
            ?>
                <tr>
                    <td><?= $k->id_kategori; ?></td>
                    <td><?= $k->kategori; ?></td>
                    <td>
                        <button class="btn btn-warning" data-toggle="modal" data-target="#edit<?= $k->id_kategori; ?>">
                            <i class="fa-solid fa-pencil"></i>
                        </button>

                        <button class="btn btn-danger" data-toggle="modal" data-target="#hapus<?= $k->id_kategori; ?>">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- tambah data -->
<div id="tambah" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Tambah Data Kategori</h3>
            </div>
            <div class="modal-body">
                <form method="post" action="<?= site_url("Kategori/tambah"); ?>">
                    <div class="form-group">
                        <label>Name</label>
                        <input type="text" class="form-control" name="kategori" placeholder="ex: Gaming">
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-success">Simpan</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- edit data -->
<?php foreach ($kategori as $k) : ?>
    <!-- edit -->
    <div id="edit<?= $k->id_kategori; ?>" class="modal fade">

        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Edit Data Kategori</h3>
                </div>
                <div class="modal-body">
                    <form method="post" action="<?= site_url("Kategori/update"); ?>">
                        <div class="form-group">
                            <label>Kategori ID</label>
                            <input type="text" class="form-control" name="id_kategori" value="<?= $k->id_kategori; ?>" readonly>
                        </div>

                        <div class="form-group">
                            <label>Nama Kategori</label>
                            <input type="text" class="form-control" name="kategori" value="<?= $k->kategori; ?>">
                        </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-success">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>

<!-- hapus -->
<?php foreach ($kategori as $k) : ?>
    <div id="hapus<?= $k->id_kategori; ?>" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Hapus Data</h3>
                </div>
                <div class="modal-body">
                    <h4>Anda ingin menghapus data <?= $k->id_kategori; ?></h4>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <a href="<?= site_url("kategori/hapus/" . $k->id_kategori); ?>" class="btn btn-danger">Hapus</a>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>