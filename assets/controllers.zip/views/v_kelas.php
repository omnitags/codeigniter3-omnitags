<div class="col-12">
    <button class="btn btn-primary" data-toggle="modal" data-target="#tambah">
        <i class="fa fa-plus"></i> Tambah Data</button>
</div>
<div class="col-12">
    <table class="table table-hover mt-3" id="data">
        <thead>
            <tr>
                <th>Id</th>
                <th>Nama</th>
                <th>Jurusan</th>
                <th>Description</th>
                <th>Foto</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (!$kelas) {
                echo "<tr><td colspan='5' class='text-center'>tidak ada data tersedia</td></tr>";
            }

            foreach ($kelas as $k) :
            ?>
                <tr>
                    <td><?= $k->id; ?></td>
                    <td><?= $k->nama; ?></td>
                    <td><?= $k->jurusan; ?></td>
                    <td><?= $k->description; ?></td>
                    <td><img class="rounded" src="<?= 'assets/upload/' . $k->foto_kelas; ?>" width="128" /></td>
                    <td>
                        <button class="btn btn-warning" data-toggle="modal" data-target="#edit<?= $k->id; ?>">
                            <i class="fa-solid fa-pencil"></i>
                        </button>

                        <button class="btn btn-danger" data-toggle="modal" data-target="#hapus<?= $k->id; ?>">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- tambah data -->
<div id="tambah" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Kelas Data</h3>
            </div>
            <div class="modal-body">
                <form enctype="multipart/form-data" method="post" action="<?= site_url("Kelas/tambah"); ?>">
                    <div class="form-group">
                        <label>Nama</label>
                        <input type="text" class="form-control" name="nama">
                    </div>

                    <div class="form-group">
                        <label>Jurusan</label>
                        <input type="text" class="form-control" name="jurusan">
                    </div>

                    <div class="form-group">
                        <label>Description</label>
                        <textarea type="text" class="form-control" name="description"></textarea>
                    </div>

                    <div class="form-group">
                        <label>Foto</label>
                        <input type="file" class="form-control-file" name="foto_kelas">
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-success">Simpan</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- edit data -->
<?php foreach ($kelas as $k) : ?>
    <!-- edit -->
    <div id="edit<?= $k->id; ?>" class="modal fade">

        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Edit Data Kelas</h3>
                </div>
                <div class="modal-body">
                    <form enctype="multipart/form-data" method="post" action="<?= site_url("Kelas/update"); ?>">
                        <div class="form-group">
                            <label>ID Kelas</label>
                            <input type="text" class="form-control" name="id" value="<?= $k->id; ?>" readonly>
                        </div>

                        <div class="form-group">
                            <label>Nama</label>
                            <input type="text" class="form-control" name="nama" value="<?= $k->nama; ?>">
                        </div>

                        <div class="form-group">
                            <label>Jurusan</label>
                            <input type="text" class="form-control" name="jurusan" value="<?= $k->jurusan; ?>">
                        </div>

                        <div class="form-group">
                            <label>Description</label>
                            <textarea type="text" class="form-control" name="description"><?= $k->description; ?></textarea>
                        </div>

                        <div class="row pt-3 pb-2">
                            <div class="col-12"><img src="assets/upload/<?= $k->foto_kelas; ?>" height="100"></div>
                        </div>

                        <div class="form-group">
                            <label>Foto</label>
                            <input type="file" class="form-control-file" name="foto_kelas">
                            <input type="hidden" name="txtfoto" value="<?= $k->foto_kelas; ?>">
                        </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-success">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>

<!-- hapus -->
<?php foreach ($kelas as $k) : ?>
    <div id="hapus<?= $k->id; ?>" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Hapus Data</h3>
                </div>
                <div class="modal-body">
                    <h4>Anda ingin menghapus profil <?= $k->nama; ?></h4>
                    <p>Melakukan ini akan mengakibatkan data yang berhubungan dengan <?= $k->nama; ?> juga ikut terhapus.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <a href="<?= site_url("kelas/hapus/" . $k->id); ?>" class="btn btn-danger">Hapus</a>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>