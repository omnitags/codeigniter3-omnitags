<div class="col-12">
    <button class="btn btn-primary" data-toggle="modal" data-target="#tambah">
        <i class="fa fa-plus"></i> Add Data</button>
    <a href="<?= site_url('Kenangan/print') ?>" target="blank" class="d-none d-sm-inline-block btn btn-sm btn-danger ml-2 shadow-sm float-right"><i class="fa-solid fa-download fa-sm text-white"></i> Generate Report</a>
</div>
<div class="col-12">
    <table class="table table-hover mt-3" id="data">
        <thead>
            <tr>
                <th>Id Kenangan</th>
                <th>Id</th>
                <th>Foto</th>
                <th>Kategori</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (!$kenangan) {
                echo "<tr><td colspan='5' class='text-center'>tidak ada data tersedia</td></tr>";
            }
            foreach ($kenangan as $k) :
            ?>
                <tr>
                    <td><?= $k->id_kenangan; ?></td>
                    <td><?= $k->id; ?></td>
                    <td><img class="rounded" src="<?= 'assets/upload/' . $k->foto; ?>" height="100" /></td>
                    <td><?= $k->kategori; ?></td>
                    <td>
                        <button class="btn btn-warning" data-toggle="modal" data-target="#edit<?= $k->id_kenangan; ?>">
                            <i class="fa-solid fa-pencil"></i>
                        </button>

                        <button class="btn btn-danger" data-toggle="modal" data-target="#hapus<?= $k->id_kenangan; ?>">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- tambah data -->
<div id="tambah" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Tambah Data</h3>
            </div>
            <div class="modal-body">
                <form method="post" action="<?= site_url("Kenangan/tambah"); ?>" enctype="multipart/form-data">
                    <div class="form-group">
                        <label>ID Kelas </label>
                        <select name="id" class="form-control" required>
                            <option value="" selected hidden>Pilih ID Kelas</option>
                            <?php foreach ($kelas as $s) { ?>
                                <option value="<?= $s->id; ?>"><?= $s->id; ?></option>
                            <?php } ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Foto</label>
                        <input type="file" class="form-control-file" name="foto">
                    </div>

                    <div class="form-group">
                        <label>Kategori </label>
                        <select name="kategori" class="form-control">
                            <option selected hidden>Pilih kategori...</option>
                            <?php foreach ($kategori as $i) { ?>
                                <option value="<?= $i->kategori; ?>"><?= $i->kategori; ?></option>
                            <?php } ?>
                        </select>
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-success">Simpan</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- edit data -->
<?php foreach ($kenangan as $k) : ?>
    <!-- edit -->
    <div id="edit<?= $k->id_kenangan; ?>" class="modal fade">

        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Edit Data Kenangan</h3>
                </div>
                <div class="modal-body">
                    <form method="post" action="<?= site_url("Kenangan/update"); ?>" enctype="multipart/form-data">
                        <div class="form-group">
                            <label>ID kenangan</label>
                            <input type="text" class="form-control" name="id_kenangan" value="<?= $k->id_kenangan; ?>" readonly>
                        </div>

                        <div class="form-group">
                            <label>ID Kelas </label>
                            <select name="id" class="form-control" required>
                                <option selected hidden><?= $k->id; ?></option>
                                <?php foreach ($kelas as $s) { ?>
                                    <option value="<?= $s->id; ?>"><?= $s->id; ?></option>
                                <?php } ?>
                            </select>
                        </div>

                        <div class="row pt-3 pb-2">
                            <div class="col-12"><img src="assets/upload/<?= $k->foto; ?>" height="100"></div>
                        </div>

                        <div class="form-group">
                            <label>Foto</label>
                            <input type="file" class="form-control-file" name="foto">
                            <input type="hidden" name="txtfoto" value="<?= $k->foto; ?>">
                        </div>

                        <div class="form-group">
                            <label>Kategori </label>
                            <select name="kategori" class="form-control">
                                <option selected hidden><?= $k->kategori; ?></option>
                                <?php foreach ($kategori as $i) { ?>
                                    <option value="<?= $i->kategori; ?>"><?= $i->kategori; ?></option>
                                <?php } ?>
                            </select>
                        </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-success">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>

<!-- hapus -->
<?php foreach ($kenangan as $k) : ?>
    <div id="hapus<?= $k->id_kenangan; ?>" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Hapus Data</h3>
                </div>
                <div class="modal-body">
                    <h4>Anda ingin menghapus data <?= $k->id_kenangan; ?></h4>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <a href="<?= site_url("kenangan/hapus/" . $k->id_kenangan); ?>" class="btn btn-danger">Hapus</a>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>