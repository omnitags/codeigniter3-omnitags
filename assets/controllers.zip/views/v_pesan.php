<div class="col-12">
    <button class="btn btn-primary" data-toggle="modal" data-target="#tambah">
        <i class="fa fa-plus"></i> Add Data</button>
</div>
<div class="col-12">
    <table class="table table-hover mt-3" id="data">
        <thead>
            <tr>
                <th>ID Pesan</th>
                <th>ID User</th>
                <th>Id</th>
                <th>Pesan</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (!$pesan) {
                echo "<tr><td colspan='5' class='text-center'>tidak ada data tersedia</td></tr>";
            }

            foreach ($pesan as $p) :
            ?>
                <tr>
                    <td><?= $p->id_pesan; ?></td>
                    <td><?= $p->id_user; ?></td>
                    <td><?= $p->id; ?></td>
                    <td><?= $p->pesan; ?></td>
                    <td>
                        <button class="btn btn-warning" data-toggle="modal" data-target="#edit<?= $p->id_pesan; ?>">
                            <i class="fa-solid fa-pencil"></i>
                        </button>

                        <button class="btn btn-danger" data-toggle="modal" data-target="#hapus<?= $p->id_pesan; ?>">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- tambah data -->
<div id="tambah" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Pesan Data</h3>
            </div>
            <div class="modal-body">
                <form method="post" action="<?= site_url("Pesan/tambah"); ?>">
                    <div class="form-group">
                        <label>ID Kelas </label>
                        <select name="id" class="form-control" required>
                            <option value="" selected hidden>Pilih ID Kelas</option>
                            <?php foreach ($kelas as $k) { ?>
                                <option value="<?= $k->id; ?>"><?= $k->id; ?></option>
                            <?php } ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <input type="hidden" class="form-control" name="id_user" value="<?= $this->session->userdata("id_user") ?>">
                    </div>

                    <div class="form-group">
                        <label>Pesan</label>
                        <input type="text" class="form-control" name="pesan">
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-success">Simpan</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- edit data -->
<?php foreach ($pesan as $p) : ?>
    <!-- edit -->
    <div id="edit<?= $p->id_pesan; ?>" class="modal fade">

        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Edit Data Pesan</h3>
                </div>
                <div class="modal-body">
                    <form method="post" action="<?= site_url("Pesan/update"); ?>">
                        <div class="form-group">
                            <label>Pesan ID</label>
                            <input type="text" class="form-control" name="id_pesan" value="<?= $p->id_pesan; ?>" readonly>
                        </div>

                        <div class="form-group">
                            <input type="hidden" class="form-control" name="nama" value="<?= $p->id_user ?>">
                        </div>

                        <div class="form-group">
                            <label>ID Kelas </label>
                            <select name="id" class="form-control" required>
                                <option selected hidden><?= $p->id ?></option>
                                <?php foreach ($kelas as $k) { ?>
                                    <option value="<?= $k->id; ?>"><?= $k->id; ?></option>
                                <?php } ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Pesan</label>
                            <input type="text" class="form-control" name="pesan" value="<?= $p->pesan; ?>">
                        </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-success">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>

<!-- hapus -->
<?php foreach ($pesan as $p) : ?>
    <div id="hapus<?= $p->id_pesan; ?>" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Hapus Data</h3>
                </div>
                <div class="modal-body">
                    <h4>Anda ingin menghapus data <?= $p->id_pesan; ?></h4>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <a href="<?= site_url("pesan/hapus/" . $p->id_pesan); ?>" class="btn btn-danger">Hapus</a>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>