<div class="col-12">
    <button class="btn btn-primary" data-toggle="modal" data-target="#tambah">
        <i class="fa fa-plus"></i> Tambah Data</button>
</div>
<div class="col-12">
    <table class="table table-hover mt-3" id="data">
        <thead>
            <tr>
                <th>Id User</th>
                <th>Id Kelas</th>
                <th>Nama</th>
                <th>Username</th>
                <th>Telp</th>
                <th>Email</th>
                <th>Foto</th>
                <th>Level</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (!$user) {
                echo "<tr><td colspan='5' class='text-center'>tidak ada data tersedia</td></tr>";
            }

            foreach ($user as $u) :
            ?>
                <tr>
                    <td><?= $u->id_user; ?></td>
                    <td><?= $u->id; ?></td>
                    <td><?= $u->nama_user; ?></td>
                    <td><?= $u->username; ?></td>
                    <td><?= $u->hp; ?></td>
                    <td><?= $u->email; ?></td>
                    <td><img src="assets/upload/<?= $u->foto; ?>" height="100"></td>
                    <td><?= $u->level; ?></td>
                    <td>
                        <button class="btn btn-warning" data-toggle="modal" data-target="#edit<?= $u->id_user; ?>">
                            <i class="fa-solid fa-pencil"></i>
                        </button>

                        <button class="btn btn-danger" data-toggle="modal" data-target="#hapus<?= $u->id_user; ?>">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- tambah data -->
<div id="tambah" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Data User</h3>
            </div>
            <div class="modal-body">
                <form method="post" action="<?= site_url("User/tambah"); ?>" enctype="multipart/form-data">
                    <div class="form-group">
                        <label>ID Kelas </label>
                        <select name="id" class="form-control" required>
                            <option value="" selected hidden>Pilih ID Kelas</option>
                            <?php foreach ($kelas as $k) { ?>
                                <option value="<?= $k->id; ?>"><?= $k->id; ?></option>
                            <?php } ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Nama</label>
                        <input type="text" class="form-control" name="nama" placeholder="ex: billy Fernando">
                    </div>

                    <div class="form-group">
                        <label>Username</label>
                        <input type="text" class="form-control" name="uname" placeholder="ex:poo123">
                    </div>

                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" class="form-control" name="pass">
                    </div>

                    <div class="form-group">
                        <label>Level </label>
                        <select name="level" class="form-control">
                            <option selected hidden>member</option>
                            <option>member</option>
                            <option>admin</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Foto</label>
                        <input type="file" class="form-control-file" name="foto">
                    </div>

                    <div class="form-group">
                        <label>No Telpon </label>
                        <input type="text" class="form-control" name="hp" placeholder="ex: 0812444444444">
                    </div>

                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" class="form-control" name="email">
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-success">Simpan</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- edit data -->
<?php foreach ($user as $u) : ?>
    <!-- edit -->
    <div id="edit<?= $u->id_user; ?>" class="modal fade">

        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Edit Data User</h3>
                </div>
                <div class="modal-body">
                    <form method="post" action="<?= site_url("User/update"); ?>" enctype="multipart/form-data">
                        <div class="form-group">
                            <label>User Id</label>
                            <input type="text" class="form-control" name="id" value="<?= $u->id_user; ?>" readonly>
                        </div>

                        <div class="form-group">
                            <label>ID Kelas </label>
                            <select name="id" class="form-control" required>
                                <option selected hidden><?= $u->id ?></option>
                                <?php foreach ($kelas as $k) { ?>
                                    <option value="<?= $k->id; ?>"><?= $k->id; ?></option>
                                <?php } ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Nama</label>
                            <input type="text" class="form-control" name="nama" value="<?= $u->nama_user; ?>">
                        </div>

                        <div class="form-group">
                            <label>Username</label>
                            <input type="text" class="form-control" name="uname" value="<?= $u->username; ?>">
                        </div>

                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" class="form-control" name="pass" value="<?= $u->password; ?>">
                        </div>

                        <div class="form-group">
                            <label>Level </label>
                            <select name="level" class="form-control">
                                <option selected hidden><?= $u->level; ?></option>
                                <option>member</option>
                                <option>admin</option>
                            </select>
                        </div>

                        <div class="row pt-3 pb-2">
                            <div class="col-12"><img src="assets/upload/<?= $u->foto; ?>" height="100"></div>
                        </div>

                        <div class="form-group">
                            <label>Foto</label>
                            <input type="file" class="form-control-file" name="foto">
                            <input type="hidden" name="txtfoto" value="<?= $u->foto; ?>">
                        </div>

                        <div class="form-group">
                            <label>No Telpon </label>
                            <input type="text" class="form-control" name="hp" value="<?= $u->hp; ?>">
                        </div>

                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" class="form-control" name="email" value="<?= $u->email; ?>">
                        </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-success">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>

<!-- hapus -->
<?php foreach ($user as $u) : ?>
    <div id="hapus<?= $u->id_user; ?>" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Hapus Data</h3>
                </div>
                <div class="modal-body">
                    <h4>Anda ingin menghapus data <?= $u->nama_user; ?></h4>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <a href="<?= site_url("user/hapus/" . $u->id_user); ?>" class="btn btn-danger">Hapus</a>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>