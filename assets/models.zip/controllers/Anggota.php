<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Anggota extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('anggota_model');
    }
    public function data_anggota()
    {
        $data['anggota'] = $this->anggota_model->data_anggota()->result();
        $data['simpanan'] = $this->anggota_model->data_simpanan()->result();
        $data['join_anggota_simpanan'] = $this->anggota_model->join2table()->result();
        $data['join_anggota_simpanan_unit'] = $this->anggota_model->join3table()->result();
        $this->load->view('anggotaview', $data);
    }
}
