<?php
class Education extends CI_Controller
{

    public function index()
    {
        $data = array(
            'title' => "Data Education",
            'konten' => "v_education",
            'education' => $this->edu->ambildata()->result(),
            'profile' => $this->pro->ambildata('profile')->result()
        );
        $this->load->view("dashboard", $data);
    }

    public function tambah()
    {
        $data = array(
            'edu_id' => "",
            'id' => $this->input->post("id"),
            'edu_year_from' => $this->input->post("edu_year_from"),
            'edu_year_to' => $this->input->post("edu_year_to"),
            'degree' => $this->input->post("degree"),
            'alma' => $this->input->post("alma")
        );
        $simpan = $this->edu->simpan($data, 'education');

        if ($simpan) {
            $this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i> Education berhasil dilaporkan</span>');
            $this->session->set_flashdata('pangggil', '$(".toast").toast("show")');
        } else {
            $this->session->set_flashdata('pesan', 'Education gagal dilaporkan');
            $this->session->set_flashdata('pangil', '$(".toast").toast("show")');
        }

        redirect(site_url('Education'));
    }

    public function update()
    {
        //update education set $data from education where $where

        $where = array('edu_id' => $this->input->post('edu_id'));
        $data = array(
            'id' => $this->input->post("id"),
            'edu_year_from' => $this->input->post("edu_year_from"),
            'edu_year_to' => $this->input->post("edu_year_to"),
            'degree' => $this->input->post("degree"),
            'alma' => $this->input->post("alma")
        );

        $simpan = $this->edu->ubah($data, $where);

        //notifikasi
        if ($simpan) {
            $this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i> Data terubah</span>');
            $this->session->set_flashdata('panggil', '$(".toast").toast("show")');
        } else {
            $this->session->set_flashdata('pesan', 'Data gagal terupdate');
            $this->session->set_flashdata('panggil', '$(".toast").toast("show")');
        }

        redirect(site_url('Education'));
    }

    public function hapus($kd)
    {
        //delete from education $where
        $where = array("edu_id" => $kd);

        $hapus = $this->edu->hapus($where);

        //notifikasi
        if ($hapus) {
            $this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i> Data terhapus</span>');
            $this->session->set_flashdata('panggil', '$(".toast").toast("show")');
        } else {
            $this->session->set_flashdata('pesan', 'Data gagal terhapus');
            $this->session->set_flashdata('panggil', '$(".toast").toast("show")');
        }

        redirect(site_url('Education'));
    }

    public function print()
    {
        $data['education'] = $this->edu->ambildata()->result();
        $this->load->view('print', $data);
    }
}
