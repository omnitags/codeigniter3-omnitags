<?php
class Experience extends CI_Controller
{

    public function index()
    {
        $data = array(
            'title' => "Data Experience",
            'konten' => "v_experience",
            'experience' => $this->exp->ambildata()->result(),
            'profile' => $this->pro->ambildata()->result()
        );
        $this->load->view("dashboard", $data);
    }

    public function tambah()
    {
        $data = array(
            'exp_id' => "",
            'id' => $this->input->post("id"),
            'exp_year_from' => $this->input->post("exp_year_from"),
            'exp_year_to' => $this->input->post("exp_year_to"),
            'company' => $this->input->post("company"),
            'exp_description' => $this->input->post("exp_description")
        );
        $simpan = $this->exp->simpan($data, 'experience');

        if ($simpan) {
            $this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i> Experience berhasil dilaporkan</span>');
            $this->session->set_flashdata('pangggil', '$(".toast").toast("show")');
        } else {
            $this->session->set_flashdata('pesan', 'Experience gagal dilaporkan');
            $this->session->set_flashdata('pangil', '$(".toast").toast("show")');
        }

        redirect(site_url('Experience'));
    }

    public function update()
    {
        //update experience set $data from experience where $where

        $where = array('exp_id' => $this->input->post('exp_id'));
        $data = array(
            'id' => $this->input->post("id"),
            'exp_year_from' => $this->input->post("exp_year_from"),
            'exp_year_to' => $this->input->post("exp_year_to"),
            'company' => $this->input->post("company"),
            'exp_description' => $this->input->post("exp_description")
        );

        $simpan = $this->exp->ubah($data, $where);

        //notifikasi
        if ($simpan) {
            $this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i> Data terubah</span>');
            $this->session->set_flashdata('panggil', '$(".toast").toast("show")');
        } else {
            $this->session->set_flashdata('pesan', 'Data gagal terupdate');
            $this->session->set_flashdata('panggil', '$(".toast").toast("show")');
        }

        redirect(site_url('Experience'));
    }

    public function hapus($kd)
    {
        //delete from experience $where
        $where = array("exp_id" => $kd);

        $hapus = $this->exp->hapus($where);

        //notifikasi
        if ($hapus) {
            $this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i> Data terhapus</span>');
            $this->session->set_flashdata('panggil', '$(".toast").toast("show")');
        } else {
            $this->session->set_flashdata('pesan', 'Data gagal terhapus');
            $this->session->set_flashdata('panggil', '$(".toast").toast("show")');
        }

        redirect(site_url('Experience'));
    }
}
