<?php
class Icon extends CI_Controller
{

	public function index()
	{
		$icon = array(
			'title' => "Data Icon",
			'konten' => "v_icon",
			'icon' => $this->ico->ambildata('icon')->result(),
		);
		$this->load->view('dashboard', $icon);
	}

	public function tambah()
	{
		$data = array(
			'icon_id' => "",
			'icon_name' => $this->input->post('icon_name'),
			'icon_type' => $this->input->post('icon_type')
		);
		$simpan = $this->ico->simpan($data);

		if ($simpan) {
			$this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i> Data tersimpans</span>');
			$this->session->set_flashdata('pangggil', '$(".toast").toast("show")');
		} else {
			$this->session->set_flashdata('pesan', 'Data gagal tersimpan');
			$this->session->set_flashdata('pangil', '$(".toast").toast("show")');
		}

		redirect(site_url('Icon'));
	}

	public function update()
	{
		//update icon set $data from icon where $where

		$where = array('icon_id' => $this->input->post('icon_id'));
		$data = array(
			'icon_name' => $this->input->post('icon_name'),
			'icon_type' => $this->input->post('icon_type')
		);

		$simpan = $this->ico->ubah($data, $where);

		//notifikasi
		if ($simpan) {
			$this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i> Data terubah</span>');
			$this->session->set_flashdata('panggil', '$(".toast").toast("show")');
		} else {
			$this->session->set_flashdata('pesan', 'Data gagal terupdate');
			$this->session->set_flashdata('panggil', '$(".toast").toast("show")');
		}

		redirect(site_url('Icon'));
	}

	public function hapus($kd)
	{
		//delete from icon $where
		$where = array("icon_id" => $kd);

		$hapus = $this->ico->hapus($where);

		//notifikasi
		if ($hapus) {
			$this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i> Data terhapus</span>');
			$this->session->set_flashdata('panggil', '$(".toast").toast("show")');
		} else {
			$this->session->set_flashdata('pesan', 'Data gagal terhapus');
			$this->session->set_flashdata('panggil', '$(".toast").toast("show")');
		}

		redirect(site_url('Icon'));
	}
}
