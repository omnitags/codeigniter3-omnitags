<?php
class Interest extends CI_Controller
{

    public function index()
    {
        $data = array(
            'title' => "Data Interest",
            'konten' => "v_interest",
            'profile' => $this->pro->ambildata()->result(),
            'interest' => $this->int->ambildata()->result(),
            'icon' => $this->ico->ambildata()->result()
        );
        $this->load->view("dashboard", $data);
    }

    public function tambah()
    {
        $data = array(
            'int_id' => "",
            'id' => $this->input->post("id"),
            'icon_name' => $this->input->post("icon_name")
        );
        $simpan = $this->int->simpan($data);

        if ($simpan) {
            $this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i> Interest berhasil dilaporkan</span>');
            $this->session->set_flashdata('pangggil', '$(".toast").toast("show")');
        } else {
            $this->session->set_flashdata('pesan', 'Interest gagal dilaporkan');
            $this->session->set_flashdata('pangil', '$(".toast").toast("show")');
        }

        redirect(site_url('Interest'));
    }

    public function update()
    {
        //update interest set $data from interest where $where

        $where = array('int_id' => $this->input->post('int_id'));
        $data = array(
            'id' => $this->input->post("id"),
            'icon_name' => $this->input->post("icon_name")
        );

        $simpan = $this->int->ubah($data, $where);

        //notifikasi
        if ($simpan) {
            $this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i> Data terubah</span>');
            $this->session->set_flashdata('panggil', '$(".toast").toast("show")');
        } else {
            $this->session->set_flashdata('pesan', 'Data gagal terupdate');
            $this->session->set_flashdata('panggil', '$(".toast").toast("show")');
        }

        redirect(site_url('Interest'));
    }

    public function hapus($kd)
    {
        //delete from interest $where
        $where = array("int_id" => $kd);

        $hapus = $this->int->hapus($where);

        //notifikasi
        if ($hapus) {
            $this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i> Data terhapus</span>');
            $this->session->set_flashdata('panggil', '$(".toast").toast("show")');
        } else {
            $this->session->set_flashdata('pesan', 'Data gagal terhapus');
            $this->session->set_flashdata('panggil', '$(".toast").toast("show")');
        }

        redirect(site_url('Interest'));
    }
}
