<?php
class Languages extends CI_Controller
{

    public function index()
    {
        $data = array(
            'title' => "Data Languages",
            'konten' => "v_languages",
            'languages' => $this->lan->ambildata()->result(),
            'profile' => $this->pro->ambildata()->result()
        );
        $this->load->view("dashboard", $data);
    }

    public function tambah()
    {
        $data = array(
            'lang_id' => "",
            'id' => $this->input->post("id"),
            'lang_name' => $this->input->post("lang_name"),
            'lang_percent' => $this->input->post("lang_percent")
        );
        $simpan = $this->lan->simpan($data, 'languages');

        if ($simpan) {
            $this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i> Languages berhasil dilaporkan</span>');
            $this->session->set_flashdata('pangggil', '$(".toast").toast("show")');
        } else {
            $this->session->set_flashdata('pesan', 'Languages gagal dilaporkan');
            $this->session->set_flashdata('pangil', '$(".toast").toast("show")');
        }

        redirect(site_url('Languages'));
    }

    public function update()
    {
        //update languages set $data from languages where $where

        $where = array('lang_id' => $this->input->post('lang_id'));
        $data = array(
            'id' => $this->input->userdata("id"),
            'lang_name' => $this->input->post("lang_name"),
            'lang_name' => $this->input->post("lang_percent")
        );

        $simpan = $this->lan->ubah($data, $where);

        //notifikasi
        if ($simpan) {
            $this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i> Data terubah</span>');
            $this->session->set_flashdata('panggil', '$(".toast").toast("show")');
        } else {
            $this->session->set_flashdata('pesan', 'Data gagal terupdate');
            $this->session->set_flashdata('panggil', '$(".toast").toast("show")');
        }

        redirect(site_url('Languages'));
    }

    public function hapus($kd)
    {
        //delete from languages $where
        $where = array("lang_id" => $kd);

        $hapus = $this->lan->hapus($where);

        //notifikasi
        if ($hapus) {
            $this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i> Data terhapus</span>');
            $this->session->set_flashdata('panggil', '$(".toast").toast("show")');
        } else {
            $this->session->set_flashdata('pesan', 'Data gagal terhapus');
            $this->session->set_flashdata('panggil', '$(".toast").toast("show")');
        }

        redirect(site_url('Languages'));
    }
}
