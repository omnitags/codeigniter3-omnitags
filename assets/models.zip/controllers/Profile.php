<?php
class Profile extends CI_Controller
{

	public function index()
	{
		$data = array(
			'title' => "Data Profile",
			'konten' => "v_profile",
			'profile' => $this->pro->ambildata('profile')->result()
		);
		$this->load->view('dashboard', $data);
	}

	public function tambah()
	{
		$config['upload_path'] = './assets/upload/';
		$config['allowed_types'] = 'jpg|jpeg|png|gif|svg|webp';

		//panggil fungsi untuk upload
		$this->load->library('upload', $config);

		//ambil into nama dan ukuran gambar
		$gambar = $_FILES['photo']['name'];
		$ukuran = $_FILES['photo']['size'];

		if ($ukuran > 0) {
			$this->upload->do_upload("photo");
		}
		$data = array(
			'id' => "",
			'name' => $this->input->post('name'),
			'work' => $this->input->post('work'),
			'pro_description' => $this->input->post('pro_description'),
			'photo' => $gambar,
			'phone' => $this->input->post('phone'),
			'email' => $this->input->post('email'),
			'web' => $this->input->post('web'),
			'linkedin' => $this->input->post('linkedin'),
			'location' => $this->input->post('location')
		);
		$simpan = $this->pro->simpan($data);

		if ($simpan) {
			$this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i> Data tersimpan</span>');
			$this->session->set_flashdata('pangggil', '$(".toast").toast("show")');
		} else {
			$this->session->set_flashdata('pesan', 'Data gagal tersimpan');
			$this->session->set_flashdata('pangil', '$(".toast").toast("show")');
		}

		redirect(site_url('Profile'));
	}

	public function update()
	{
		//update profile set $data from profile where $where

		$config['upload_path'] = './assets/upload/';
		$config['allowed_types'] = 'jpg|jpeg|png|gif|webp';

		//panggil fungsi untuk upload
		$this->load->library('upload', $config);

		//ambil into nama dan ukuran gambar
		$gambar = $_FILES['photo']['name'];

		if ($gambar) {
			$this->upload->do_upload("photo");
		}

		$where = array('id' => $this->input->post('id'));
		$data = array(
			'name' => $this->input->post('name'),
			'work' => $this->input->post('work'),
			'pro_description' => $this->input->post('pro_description'),
			'photo' => $gambar,
			'phone' => $this->input->post('phone'),
			'email' => $this->input->post('email'),
			'web' => $this->input->post('web'),
			'linkedin' => $this->input->post('linkedin'),
			'location' => $this->input->post('location')
		);

		$simpan = $this->pro->ubah($data, $where);

		//notifikasi
		if ($simpan) {
			$this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i> Data terubah</span>');
			$this->session->set_flashdata('panggil', '$(".toast").toast("show")');
		} else {
			$this->session->set_flashdata('pesan', 'Data gagal terupdate');
			$this->session->set_flashdata('panggil', '$(".toast").toast("show")');
		}

		redirect(site_url('Profile'));
	}

	public function hapus($kd)
	{
		//delete from profile $where
		$where = array("id" => $kd);

		$hapus = $this->pro->hapus($where);

		//notifikasi
		if ($hapus) {
			$this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i> Data terhapus</span>');
			$this->session->set_flashdata('panggil', '$(".toast").toast("show")');
		} else {
			$this->session->set_flashdata('pesan', 'Data gagal terhapus');
			$this->session->set_flashdata('panggil', '$(".toast").toast("show")');
		}

		redirect(site_url('Profile'));
	}
}
