<?php
class Skills extends CI_Controller
{

    public function index()
    {
        $data = array(
            'title' => "Data Skills",
            'konten' => "v_skills",
            'skills' => $this->skl->ambildata()->result(),
            'profile' => $this->pro->ambildata()->result()
        );
        $this->load->view("dashboard", $data);
    }

    public function tambah()
    {
        $data = array(
            'skill_id' => "",
            'id' => $this->input->post("id"),
            'skill_name' => $this->input->post("skill_name"),
            'skill_percent' => $this->input->post("skill_percent")
        );
        $simpan = $this->skl->simpan($data, 'skills');

        if ($simpan) {
            $this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i> Skills berhasil dilaporkan</span>');
            $this->session->set_flashdata('pangggil', '$(".toast").toast("show")');
        } else {
            $this->session->set_flashdata('pesan', 'Skills gagal dilaporkan');
            $this->session->set_flashdata('pangil', '$(".toast").toast("show")');
        }

        redirect(site_url('Skills'));
    }

    public function update()
    {
        //update skills set $data from skills where $where

        $where = array('skill_id' => $this->input->post('skill_id'));
        $data = array(
            'id' => $this->input->post("id"),
            'skill_name' => $this->input->post("skill_name"),
            'skill_percent' => $this->input->post("skill_percent")
        );

        $simpan = $this->skl->ubah($data, $where);

        //notifikasi
        if ($simpan) {
            $this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i> Data terubah</span>');
            $this->session->set_flashdata('panggil', '$(".toast").toast("show")');
        } else {
            $this->session->set_flashdata('pesan', 'Data gagal terupdate');
            $this->session->set_flashdata('panggil', '$(".toast").toast("show")');
        }

        redirect(site_url('Skills'));
    }

    public function hapus($kd)
    {
        //delete from skills $where
        $where = array("skill_id" => $kd);

        $hapus = $this->skl->hapus($where);

        //notifikasi
        if ($hapus) {
            $this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i> Data terhapus</span>');
            $this->session->set_flashdata('panggil', '$(".toast").toast("show")');
        } else {
            $this->session->set_flashdata('pesan', 'Data gagal terhapus');
            $this->session->set_flashdata('panggil', '$(".toast").toast("show")');
        }

        redirect(site_url('Skills'));
    }
}
