<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Welcome extends CI_Controller
{

	public function index()
	{
		$data = array(
			'title' => "Curriculum Vitae Checkout",
			'konten' => "v_home"
		);
		$this->load->view('login', $data);
	}

	public function home()
	{
		$data = array(
			'title' => "Choose Your Profile",
			'konten' => "v_home",
			'profile' => $this->pro->ambildata('profile')->result()
		);
		$this->load->view('dashboard', $data);
	}

	public function ceklogin()
	{
		$username = $this->input->post('uname');
		$password = $this->input->post('pass');
		$login = $this->pts->ceklogin($username, $password, "petugas");

		if ($login->num_rows() > 0) {
			$user = $login->result();

			//print_r($user);
			$nama = $user[0]->nama_petugas;
			$level = $user[0]->level;

			//buat session
			$this->session->set_userdata("nama", $nama);
			$this->session->set_userdata("akses", $level);

			$this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i>Login Berhasil</span>');
			$this->session->set_flashdata('panggil', '$(".toast").toast("show")');

			redirect('welcome/home');
		} else {
			$this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i>Login Gagal</span>');
			$this->session->set_flashdata('panggil', '$(".toast").toast("show")');

			redirect('welcome');
		}
	}

	public function result($input = null)
	{
		$input = $this->input->post('txtid');
		$id = $this->pro->ambil($input);
		$data = array(
			'title' => 'CV',
			'profile' => $id,
			'education' => $this->edu->join2table($id[0]->id)->result(),
			'experience' => $this->exp->join2table($id[0]->id)->result(),
			'interest' => $this->int->join2table($id[0]->id)->result(),
			'languages' => $this->lan->join2table($id[0]->id)->result(),
			'skills' => $this->skl->join2table($id[0]->id)->result()
		);
		if (isset($_POST['btnsimpan'])) {
			$this->load->view("cv.php", $data);
		} elseif (isset($_POST['btncetak'])) {
			$mpdf = new \Mpdf\Mpdf();
			ob_start();
			$html = $this->load->view('cv.php', $data);;
			$html = ob_get_contents();
			ob_end_clean();
			$mpdf->WriteHTML($html);
			$mpdf->Output();
		}
	}

	public function resume()
	{
		$this->load->view('resume.html');
	}

	public function logout()
	{
		session_destroy();

		//buat session
		$this->session->set_flashdata('pesan', '<span class="text-success"><i class="far fa-check-square"></i>Sesi anda telah berakhir</span>');
		$this->session->set_flashdata('panggil', '$(".toast").toast("show")');
		redirect(site_url("welcome"));
	}
}
