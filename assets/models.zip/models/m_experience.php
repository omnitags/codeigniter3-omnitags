<?php
class m_experience extends CI_Model
{
  private $tabel = 'experience';

  public function ambildata()
  {
    return $this->db->get($this->tabel);
  }

  public function ambil($id)
  {
    //select * from $tabel where id = $id
    return $this->db->get_where($this->tabel, ["id" => $id])->row();
  }

  function join2table($id)
  {
    $this->db->select('*');
    $this->db->from('experience');
    $this->db->join('profile', 'profile.id = experience.id');
    $this->db->where("profile.id", $id);
    $query = $this->db->get();
    return $query;
  }

  public function simpan($data)
  {
    return $this->db->insert($this->tabel, $data);
  }

  public function ubah($data, $where)
  {
    $this->db->where($where);
    return $this->db->update($this->tabel, $data, $where);
  }

  public function hapus($where)
  {
    return $this->db->delete($this->tabel, $where);
  }
}
