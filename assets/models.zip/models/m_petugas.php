<?php
class m_petugas extends CI_Model
{
  private $tabel = 'petugas';

  public function ambildata()
  {
    return $this->db->get($this->tabel);
  }

  public function simpan($datapetugas)
  {
    return $this->db->insert($this->tabel, $datapetugas);
  }

  public function ubah($data, $where)
  {
    $this->db->where($where);
    return $this->db->update($this->tabel, $data, $where);
  }

  public function hapus($where)
  {
    return $this->db->delete($this->tabel, $where);
  }

  public function ceklogin($username, $password)
  {
    $this->db->where('username', $username);
    $this->db->where('password', $password);
    return $this->db->get($this->tabel);
  }
}
