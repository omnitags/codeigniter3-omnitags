<base href="<?php echo base_url(); ?>">
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?> - <?php foreach ($profile as $p) {
                                echo $p->name;
                            } ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/fontawesome/css/all.css">
</head>

<body>
    <div class="container">
        <div class="left_Side">
            <div class="profileText">

                <?php
                if (!$profile) {
                    echo "<tr><td colspan='5' class='text-center'>tidak ada data tersedia</td></tr>";
                } else {

                    foreach ($profile as $p) {
                ?>
                        <div class="img8x">
                            <img src="<?= 'assets/upload/' . $p->photo; ?>" alt="">
                        </div>

                        <h2><?= $p->name; ?><br><span><?= $p->work; ?></span></h2>
                <?php }
                } ?>

            </div>

            <div class="contactInfo">
                <h3 class="title">Contact Info</h3>

                <?php
                if (!$profile) {
                    echo "<tr><td colspan='5' class='text-center'>tidak ada data tersedia</td></tr>";
                } else {

                    foreach ($profile as $p) {
                ?>
                        <ul>

                            <li>
                                <span class="icon"><i class="fa-solid fa-phone" aria-hidden="true"></i></span>
                                <span class="text"><?= $p->phone; ?></span>
                            </li>
                            <li>
                                <span class="icon"><i class="fa-solid fa-envelope" aria-hidden="true"></i></span>
                                <span class="text"><?= $p->email; ?></span>
                            </li>
                            <li>
                                <span class="icon"><i class="fa-solid fa-globe" aria-hidden="true"></i></span>
                                <span class="text"><?= $p->web; ?></span>
                            </li>
                            <li>
                                <span class="icon"><i class="fa-brands fa-linkedin" aria-hidden="true"></i></span>
                                <span class="text"><?= $p->linkedin; ?></span>
                            </li>
                            <li>
                                <span class="icon"><i class="fa-solid fa-location-dot" aria-hidden="true"></i></span>
                                <span class="text"><?= $p->location; ?></span>
                            </li>

                        </ul>
                <?php }
                } ?>
            </div>

            <div class="contactInfo education">
                <h3 class="title">Education</h3>
                <?php
                if (!$education) {
                    echo "<tr><td colspan='5' class='text-center'>tidak ada data tersedia</td></tr>";
                } else {

                    foreach ($education as $e) {
                ?>
                        <ul>
                            <li>
                                <h5><?= $e->edu_year_from; ?> - <?= $e->edu_year_to; ?></h5>
                                <h4><?= $e->degree; ?></h4>
                                <h4><?= $e->alma; ?></h4>
                            </li>
                        </ul>
                <?php }
                } ?>

            </div>

            <div class="contactInfo language">
                <h3 class="title">Languages</h3>
                <?php
                if (!$languages) {
                    echo "<span class='text'>tidak ada data tersedia</span>";
                } else {

                    foreach ($languages as $l) {
                ?>
                        <ul>
                            <li>
                                <span class="text"><?= $l->lang_name; ?></span>
                                <span class="percent">
                                    <div style="width: <?= $l->lang_percent; ?>%;"></div>
                                </span>
                            </li>
                        </ul>
                <?php }
                } ?>

            </div>
        </div>
        <div class="right_Side">
            <div class="about">
                <h2 class="title2">Profile</h2>
                <?php
                if (!$profile) {
                    echo "<tr><td colspan='5' class='text-center'>tidak ada data tersedia</td></tr>";
                } else {

                    foreach ($profile as $p) {
                        //menambahkan enter 2 kali di deskripsi
                ?>
                        <p><?= nl2br(htmlspecialchars($p->pro_description)); ?></p>
                <?php }
                } ?>
            </div>
            <div class="about">
                <h2 class="title2">Experience</h2>
                <?php
                if (!$experience) {
                    echo "<tr><td colspan='5' class='text-center'>tidak ada data tersedia</td></tr>";
                } else {

                    foreach ($experience as $x) :
                ?>
                        <div class="box">
                            <div class="year_company">
                                <h5><?= $x->exp_year_from; ?> - <?= $x->exp_year_to; ?></h5>
                                <h5><?= $x->company; ?></h5>
                            </div>

                            <div class="text">
                                <h4><?= $x->position; ?></h4>
                                <p><?= $x->exp_description; ?></p>
                            </div>
                        </div>
                <?php endforeach;
                } ?>
            </div>

            <div class="about skills">
                <h2 class="title2">Professional Skills</h2>
                <?php
                if (!$skills) {
                    echo "<tr><td colspan='5' class='text-center'>tidak ada data tersedia</td></tr>";
                } else {

                    foreach ($skills as $s) {
                ?>
                        <div class="box">
                            <h4><?= $s->skill_name; ?></h4>
                            <div class="percent">
                                <div style="width: <?= $s->skill_percent; ?>%;"></div>
                            </div>
                        </div>
                <?php }
                } ?>
            </div>

            <div class="about interest">
                <h2 class="title2">Interest</h2>
                <ul>
                    <?php
                    if (!$interest) {
                        echo "<tr><td colspan='5' class='text-center'>tidak ada data tersedia</td></tr>";
                    } else {

                        foreach ($interest as $i) {
                    ?>
                            <li><i class="fa-solid fa-<?= $i->icon_type; ?>" aria-hidden="true"></i> <?= $i->icon_name; ?></li>
                    <?php }
                    } ?>
                </ul>

            </div>

        </div>
    </div>
</body>

</html>