<a href="<?= site_url("welcome/home") ?>">Home</a>
<a href="<?= site_url('profile'); ?>">Profile</a>

<a class="h5">Profile Information</a>
<a href="<?= site_url('education'); ?>">Education</a>
<a href="<?= site_url('languages'); ?>">Languages</a>
<a href="<?= site_url('experience'); ?>">Experience</a>
<a href="<?= site_url('skills'); ?>">Skills</a>
<a href="<?= site_url('interest'); ?>">Interest</a>

<a class="h5">Miscelaneus</a>
<a href="<?= site_url('icon'); ?>">Icon</a>
<a href="<?= site_url('petugas'); ?>">Data User</a>

<a href="<?= site_url("welcome/logout") ?>">Logout</a>