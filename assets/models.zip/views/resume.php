<base href="<?php echo base_url(); ?>">
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- bootstrap -->
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">

    <!-- custom css -->
    <link rel="stylesheet" href="assets/resume.css">

    <!-- fontawesome -->
    <link rel="stylesheet" href="assets/fontawesome/css/all.css">

    <!-- scripts -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.min.js"></script>

    <title><?= $title ?> - <?php foreach ($profile as $p) {
                                echo $p->name;
                            } ?></title>
</head>

<body>
    <!-- Header Section -->
    <section id="header">
        <div class="container text-center">
            <div class="user-box">
                <?php
                if (!$profile) {
                    echo "<tr><td colspan='5' class='text-center'>tidak ada data tersedia</td></tr>";
                } else {

                    foreach ($profile as $p) {
                ?>
                        <img src="<?= 'assets/upload/' . $p->photo; ?>" alt="">
                        <h1><?= $p->name; ?></h1>
                        <p><?= $p->work; ?></p>

                <?php }
                } ?>

            </div>

        </div>
        <div class="scroll-btn">
            <div class="scroll-bar">
                <a href="#about"><span> </span></a>
            </div>
        </div>
    </section>

    <!-- User Info Section -->
    <section id="user-info">
        <div class="nav-bar">
            <nav class="navbar navbar-expand-lg">
                <a class="navbar-brand" href="#"><img src="img/john.jpg" alt=""></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa-solid fa-bars"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="#top">HOME</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#about">ABOUT ME</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#resume">RESUME</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#services">SERVICES</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#contact">CONTACT</a>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>

        <!-- About -->
        <div class="about container" id="about">
            <?php
            if (!$profile) {
                echo "<tr><td colspan='5' class='text-center'>tidak ada data tersedia</td></tr>";
            } else {

                foreach ($profile as $p) {
            ?>
                    <div class="row">
                        <div class="col-md-6 text-center">

                            <img src="<?= 'assets/upload/' . $p->photo; ?>" alt="">
                        </div>
                        <div class="col-md-6">
                            <h3>WHO AM I ?</h3>
                            <p><?= nl2br(htmlspecialchars($p->pro_description)); ?></p>
                    <?php }
            } ?>


                    <?php
                    if (!$skills) {
                        echo "<tr><td colspan='5' class='text-center'>tidak ada data tersedia</td></tr>";
                    } else {

                        foreach ($skills as $s) {
                    ?>
                            <div class="skills-bar">
                                <p><?= $s->skill_name; ?></p>
                                <div class="progress">
                                    <div class="progress-bar" style="width: <?= $s->skill_percent; ?>%;"><?= $s->skill_percent; ?>%</div>
                                </div>
                            </div>

                    <?php }
                    } ?>
                        </div>
                    </div>



        </div>

        <!-- Social icons -->
        <div class="social-icons">
            <?php
            if (!$profile) {
                echo "<tr><td colspan='5' class='text-center'>tidak ada data tersedia</td></tr>";
            } else {

                foreach ($profile as $p) {
            ?>
                    <ul>
                        <a href="<?= $p->linkedin; ?>">
                            <li><i class="fa-brands fa-linkedin"></i></li>
                        </a>
                    </ul>
            <?php }
            } ?>
        </div>

        <!-- Resume -->
        <div class="resume" id="resume">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <h3 class="text-center">My Experiences</h3>

                        <?php
                        if (!$experience) {
                            echo "<tr><td colspan='5' class='text-center'>tidak ada data tersedia</td></tr>";
                        } else {

                            foreach ($experience as $x) :
                        ?>
                                <ul class="timeline">
                                    <li>
                                        <h4><span><?= $x->exp_year_to; ?> - </span><?= $x->position; ?></h4>
                                        <p><?= $x->exp_description; ?><br>
                                            <b>Company</b> - <?= $x->company; ?><br>
                                            <b>Duration</b> - <?= $x->exp_year_from; ?> - <?= $x->exp_year_to; ?><br>
                                        </p>
                                    </li>

                                </ul>

                        <?php endforeach;
                        } ?>
                    </div>
                    <div class="col-md-6">
                        <h3 class="text-center">My Education</h3>
                        <?php
                        if (!$education) {
                            echo "<tr><td colspan='5' class='text-center'>tidak ada data tersedia</td></tr>";
                        } else {

                            foreach ($education as $e) {
                        ?>
                                <ul class="timeline">
                                    <li>
                                        <h4><span><?= $e->edu_year_from; ?> - </span> <?= $e->degree; ?></h4>
                                        <p>
                                            <b>Institute</b> - <?= $e->alma; ?><br>
                                            <b>Session</b><?= $e->edu_year_from; ?> - <?= $e->edu_year_to; ?><br>
                                            <b>Aggregate</b>80.00%<br>
                                        </p>
                                    </li>

                                </ul>
                        <?php }
                        } ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Contact -->

        <div class="contact" id="contact">
            <div class="container text-center">
                <h1>Contact Me</h1>
                <?php
                if (!$profile) {
                    echo "<tr><td colspan='5' class='text-center'>tidak ada data tersedia</td></tr>";
                } else {

                    foreach ($profile as $p) {
                ?>
                        <p class="text-center">Subscribe <?= $p->name; ?> to <br>
                            watch more videos on website Development and Digital Marketing.</p>

                        <div class="row">
                            <div class="col-md-4">
                                <i class="fa-solid fa-phone" id="fa"></i>
                                <p><?= $p->phone; ?></p>
                            </div>
                            <div class="col-md-4">
                                <i class="fa-solid fa-envelope" id="fa"></i>
                                <p><?= $p->email; ?></p>
                            </div>
                            <div class="col-md-4">
                                <i class="fa-brands fa-edge" id="fa"></i>
                                <p><?= $p->web; ?></p>
                            </div>
                        </div>

                        <button type="button" class="btn btn-primary"><i class="fa-solid fa-download" id="fa"></i>Resume</button>
                        <button type="button" class="btn btn-primary"><i class="fa-solid fa-rocket" id="fa"></i>Hire Me</button>

                <?php }
                } ?>
            </div>

            <div class="footer text-center">
                <p>Made with <i class="fa-regular fa-heart" id="fa"></i> by Easy Tutorials</p>
            </div>
        </div>

    </section>

    <!-- Smooth Scroll -->
    <script src="smooth-scroll.js"></script>
    <script>
        var scroll = new SmoothScroll('a[href*="#"]');
    </script>
</body>

</html>