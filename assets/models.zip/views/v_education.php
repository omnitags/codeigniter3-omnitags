<div class="col-12">
    <button class="btn btn-primary" data-toggle="modal" data-target="#tambah">
        <i class="fa fa-plus"></i> Add Data</button>
    <a href="<?= site_url('Education/print') ?>" target="blank" class="d-none d-sm-inline-block btn btn-sm btn-danger ml-2 shadow-sm float-right"><i class="fa-solid fa-download fa-sm text-white"></i> Generate Report</a>
</div>
<div class="col-12">
    <table class="table table-hover mt-3" id="data">
        <thead>
            <tr>
                <th>Edu Id</th>
                <th>Id</th>
                <th>From</th>
                <th>To</th>
                <th>Degree</th>
                <th>Alma</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (!$education) {
                echo "<tr><td colspan='5' class='text-center'>tidak ada data tersedia</td></tr>";
            }
            foreach ($education as $e) :
            ?>
                <tr>
                    <td><?= $e->edu_id; ?></td>
                    <td><?= $e->id; ?></td>
                    <td><?= $e->edu_year_from; ?></td>
                    <td><?= $e->edu_year_to; ?></td>
                    <td><?= $e->degree; ?></td>
                    <td><?= $e->alma; ?></td>
                    <td>
                        <button class="btn btn-warning" data-toggle="modal" data-target="#edit<?= $e->edu_id; ?>">
                            <i class="fa-solid fa-pencil"></i>
                        </button>

                        <button class="btn btn-danger" data-toggle="modal" data-target="#hapus<?= $e->edu_id; ?>">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- tambah data -->
<div id="tambah" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Education Data</h3>
            </div>
            <div class="modal-body">
                <form method="post" action="<?= site_url("Education/tambah"); ?>">
                    <div class="form-group">
                        <label>Profile ID </label>
                        <select name="id" class="form-control" required>
                            <option value="" selected hidden>Choose your ID</option>
                            <?php foreach ($profile as $p) { ?>
                                <option value="<?= $p->id; ?>"><?= $p->id; ?></option>
                            <?php } ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Year From</label>
                        <input type="text" class="form-control" name="edu_year_from" placeholder="ex: 2000">
                    </div>

                    <div class="form-group">
                        <label>Year To</label>
                        <input type="text" class="form-control" name="edu_year_to" placeholder="ex: 2004">
                    </div>

                    <div class="form-group">
                        <label>Degree</label>
                        <input type="text" class="form-control" name="degree" placeholder="ex: Master Degree of Science">
                    </div>

                    <div class="form-group">
                        <label>Alma</label>
                        <input type="text" class="form-control" name="alma" placeholder="ex: University of Melbourne">
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-success">Simpan</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- edit data -->
<?php foreach ($education as $e) : ?>
    <!-- edit -->
    <div id="edit<?= $e->edu_id; ?>" class="modal fade">

        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Edit Data Education</h3>
                </div>
                <div class="modal-body">
                    <form method="post" action="<?= site_url("Education/update"); ?>">
                        <div class="form-group">
                            <label>Education ID</label>
                            <input type="text" class="form-control" name="edu_id" value="<?= $e->edu_id; ?>" readonly>
                        </div>

                        <div class="form-group">
                            <label>Profile Id</label>
                            <input type="text" class="form-control" name="id" value="<?= $e->id; ?>" readonly>
                        </div>

                        <div class="form-group">
                            <label>Year From</label>
                            <input type="text" class="form-control" name="edu_year_from" value="<?= $e->edu_year_from; ?>">
                        </div>

                        <div class="form-group">
                            <label>Year To</label>
                            <input type="text" class="form-control" name="edu_year_to" value="<?= $e->edu_year_to; ?>">
                        </div>

                        <div class="form-group">
                            <label>Degree</label>
                            <input type="text" class="form-control" name="degree" value="<?= $e->degree; ?>">
                        </div>

                        <div class="form-group">
                            <label>Alma</label>
                            <input type="text" class="form-control" name="alma" value="<?= $e->alma; ?>">
                        </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-success">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>

<!-- hapus -->
<?php foreach ($education as $e) : ?>
    <div id="hapus<?= $e->edu_id; ?>" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Hapus Data</h3>
                </div>
                <div class="modal-body">
                    <h4>Anda ingin menghapus data <?= $e->edu_id; ?></h4>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <a href="<?= site_url("education/hapus/" . $e->edu_id); ?>" class="btn btn-danger">Hapus</a>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>