<div class="col-12">
    <button class="btn btn-primary" data-toggle="modal" data-target="#tambah">
        <i class="fa fa-plus"></i> Add Data</button>
</div>
<div class="col-12">
    <table class="table table-hover mt-3" id="data">
        <thead>
            <tr>
                <th>Exp Id</th>
                <th>Id</th>
                <th>From</th>
                <th>To</th>
                <th>Company</th>
                <th>Position</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (!$experience) {
                echo "<tr><td colspan='5' class='text-center'>tidak ada data tersedia</td></tr>";
            }
            foreach ($experience as $x) :
            ?>
                <tr>
                    <td><?= $x->exp_id; ?></td>
                    <td><?= $x->id; ?></td>
                    <td><?= $x->exp_year_from; ?></td>
                    <td><?= $x->exp_year_to; ?></td>
                    <td><?= $x->company; ?></td>
                    <td><?= $x->position; ?></td>
                    <td>
                        <button class="btn btn-warning" data-toggle="modal" data-target="#edit<?= $x->exp_id; ?>">
                            <i class="fa-solid fa-pencil"></i>
                        </button>

                        <button class="btn btn-danger" data-toggle="modal" data-target="#hapus<?= $x->exp_id; ?>">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- tambah data -->
<div id="tambah" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Experience Data</h3>
            </div>
            <div class="modal-body">
                <form method="post" action="<?= site_url("Experience/tambah"); ?>">
                    <div class="form-group">
                        <label>Profile ID </label>
                        <select name="id" class="form-control" required>
                            <option value="" selected hidden>Choose your ID</option>
                            <?php foreach ($profile as $p) { ?>
                                <option value="<?= $p->id; ?>"><?= $p->id; ?></option>
                            <?php } ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Year From</label>
                        <input type="text" class="form-control" name="exp_year_from" placeholder="ex: 2000">
                    </div>

                    <div class="form-group">
                        <label>Year To</label>
                        <input type="text" class="form-control" name="exp_year_to" placeholder="ex: 2004">
                    </div>

                    <div class="form-group">
                        <label>Company</label>
                        <input type="text" class="form-control" name="company" placeholder="ex: Tesla Corporation">
                    </div>

                    <div class="form-group">
                        <label>Position</label>
                        <input type="text" class="form-control" name="position" placeholder="ex: Programmer">
                    </div>

                    <div class="form-group">
                        <label>Description</label>
                        <textarea type="text" class="form-control" name="exp_description"></textarea>
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-success">Simpan</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- edit data -->
<?php foreach ($experience as $x) : ?>
    <!-- edit -->
    <div id="edit<?= $x->exp_id; ?>" class="modal fade">

        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Edit Data Experience</h3>
                </div>
                <div class="modal-body">
                    <form method="post" action="<?= site_url("Experience/update"); ?>">
                        <div class="form-group">
                            <label>Experience ID</label>
                            <input type="text" class="form-control" name="exp_id" value="<?= $x->exp_id; ?>" readonly>
                        </div>

                        <div class="form-group">
                            <label>Profile Id</label>
                            <input type="text" class="form-control" name="id" value="<?= $x->id; ?>" readonly>
                        </div>

                        <div class="form-group">
                            <label>Year From</label>
                            <input type="text" class="form-control" name="exp_year_from" value="<?= $x->exp_year_from; ?>">
                        </div>

                        <div class="form-group">
                            <label>Year To</label>
                            <input type="text" class="form-control" name="exp_year_to" value="<?= $x->exp_year_to; ?>">
                        </div>

                        <div class="form-group">
                            <label>Company</label>
                            <input type="text" class="form-control" name="company" value="<?= $x->company; ?>">
                        </div>

                        <div class="form-group">
                            <label>Position</label>
                            <input type="text" class="form-control" name="position" value="<?= $x->position; ?>">
                        </div>

                        <div class="form-group">
                            <label>Description</label>
                            <textarea type="text" class="form-control" name="exp_description"><?= $x->exp_description; ?>"</textarea>
                        </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-success">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>

<!-- hapus -->
<?php foreach ($experience as $x) : ?>
    <div id="hapus<?= $x->exp_id; ?>" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Hapus Data</h3>
                </div>
                <div class="modal-body">
                    <h4>Anda ingin menghapus data <?= $x->exp_id; ?></h4>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <a href="<?= site_url("experience/hapus/" . $x->exp_id); ?>" class="btn btn-danger">Hapus</a>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>