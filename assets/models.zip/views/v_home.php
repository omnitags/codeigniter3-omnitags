<div class="col-12">
	<button class="btn btn-primary" data-toggle="modal" data-target="#pilih">
		<i class="fa fa-plus"></i> View Results</button>
</div>
<!-- pilih data -->
<div id="pilih" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h3>Choose Profile ID</h3>
			</div>
			<div class="modal-body">
				<form method="post" action="<?= site_url("welcome/result"); ?>">
					<div class="form-group">
						<label>Profile ID </label>
						<select name="txtid" class="form-control" required>
							<option value="" selected hidden>Choose your ID</option>
							<?php foreach ($profile as $p) { ?>
								<option value="<?= $p->id; ?>"><?= $p->id; ?></option>
							<?php } ?>
						</select>
					</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<button name="btnsimpan" type="submit" class="btn btn-success" onclick="newWindow()">Simpan</button>
				<button name="btncetak" type="submit" class="btn btn-success" onclick="newWindow()">Cetak</button>
				</form>
			</div>
		</div>
	</div>
</div>