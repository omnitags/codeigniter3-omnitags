<div class="col-12">
    <button class="btn btn-primary" data-toggle="modal" data-target="#tambah">
        <i class="fa fa-plus"></i> Add Data</button>
</div>
<div class="col-12 scoll">
    <table class="table table-sm table-hover mt-3" id="data">
        <thead>
            <tr>
                <th>Icon Id</th>
                <th>Icon Name</th>
                <th>Fontawesome solid class</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (!$icon) {
                echo "<tr><td colspan='5' class='text-center'>tidak ada data tersedia</td></tr>";
            }
            foreach ($icon as $o) :
            ?>
                <tr>
                    <td><?= $o->icon_id; ?></td>
                    <td><?= $o->icon_name; ?></td>
                    <td><?= $o->icon_type; ?></td>
                    <td>
                        <button class="btn btn-warning" data-toggle="modal" data-target="#edit<?= $o->icon_id; ?>">
                            <i class="fa-solid fa-pencil"></i>
                        </button>

                        <button class="btn btn-danger" data-toggle="modal" data-target="#hapus<?= $o->icon_id; ?>">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- tambah data -->
<div id="tambah" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Icon Data</h3>
            </div>
            <div class="modal-body">
                <form method="post" action="<?= site_url("Icon/tambah"); ?>">
                    <div class="form-group">
                        <label>Name</label>
                        <input type="text" class="form-control" name="icon_name" placeholder="ex: Gaming">
                    </div>

                    <div class="form-group">
                        <label>Fontawesome Solid Type</label>
                        <input type="text" class="form-control" name="icon_type" placeholder="ex: gamepad">
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-success">Simpan</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- edit data -->
<?php foreach ($icon as $o) : ?>
    <!-- edit -->
    <div id="edit<?= $o->icon_id; ?>" class="modal fade">

        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Edit Data Icon</h3>
                </div>
                <div class="modal-body">
                    <form method="post" action="<?= site_url("Icon/update"); ?>">
                        <div class="form-group">
                            <label>Icon ID</label>
                            <input type="text" class="form-control" name="icon_id" value="<?= $o->icon_id; ?>" readonly>
                        </div>

                        <div class="form-group">
                            <label>Icon Name</label>
                            <input type="text" class="form-control" name="icon_name" value="<?= $o->icon_name; ?>">
                        </div>

                        <div class="form-group">
                            <label>Icon Type</label>
                            <input type="text" class="form-control" name="icon_type" value="<?= $o->icon_type; ?>">
                        </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-success">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>

<!-- hapus -->
<?php foreach ($icon as $o) : ?>
    <div id="hapus<?= $o->icon_id; ?>" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Hapus Data</h3>
                </div>
                <div class="modal-body">
                    <h4>Anda ingin menghapus data <?= $o->icon_id; ?></h4>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <a href="<?= site_url("icon/hapus/" . $o->icon_id); ?>" class="btn btn-danger">Hapus</a>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>