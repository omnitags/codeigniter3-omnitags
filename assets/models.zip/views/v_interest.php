<div class="col-12">
    <button class="btn btn-primary" data-toggle="modal" data-target="#tambah">
        <i class="fa fa-plus"></i> Add Interest</button>
</div>
<div class="col-12">
    <table class="table table-hover mt-3" id="data">
        <thead>
            <tr>
                <th>Int Id</th>
                <th>Id</th>
                <th>Name</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (!$interest) {
                echo "<tr><td colspan='5' class='text-center'>tidak ada data tersedia</td></tr>";
            }

            foreach ($interest as $i) :
            ?>
                <tr>
                    <td><?= $i->int_id; ?></td>
                    <td><?= $i->id; ?></td>
                    <td><?= $i->icon_name; ?></td>
                    <td>
                        <button class="btn btn-warning" data-toggle="modal" data-target="#edit<?= $i->int_id; ?>">
                            <i class="fa-solid fa-pencil"></i>
                        </button>

                        <button class="btn btn-danger" data-toggle="modal" data-target="#hapus<?= $i->int_id; ?>">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- tambah data -->
<div id="tambah" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Interest Data</h3>
            </div>
            <div class="modal-body">
                <form method="post" action="<?= site_url("Interest/tambah"); ?>">
                    <div class="form-group">
                        <label>Profile ID </label>
                        <select name="id" class="form-control" required>
                            <option value="" selected hidden>Choose your ID</option>
                            <?php foreach ($profile as $p) { ?>
                                <option value="<?= $p->id; ?>"><?= $p->id; ?></option>
                            <?php } ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Interest</label>
                        <select name="icon_name" class="form-control" required>
                            <option value="" selected hidden>Choose interest</option>
                            <?php foreach ($icon as $o) { ?>
                                <option value="<?= $o->icon_name; ?>"><?= $o->icon_name; ?></option>
                            <?php } ?>
                        </select>
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-success">Simpan</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- edit data -->
<?php foreach ($interest as $i) : ?>
    <!-- edit -->
    <div id="edit<?= $i->int_id; ?>" class="modal fade">

        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Edit Data Interest</h3>
                </div>
                <div class="modal-body">
                    <form method="post" action="<?= site_url("Interest/update"); ?>">
                        <div class="form-group">
                            <label>Interest ID</label>
                            <input type="text" class="form-control" name="int_id" value="<?= $i->int_id; ?>" readonly>
                        </div>

                        <div class="form-group">
                            <label>Profile Id</label>
                            <input type="text" class="form-control" name="id" value="<?= $i->id; ?>" readonly>
                        </div>

                        <div class="form-group">
                            <label>Interest</label>
                            <select name="icon_name" class="form-control" required>
                                <option value="<?php $i->icon_name; ?>" selected hidden></option>
                                <?php foreach ($icon as $o) { ?>
                                    <option value="<?= $o->icon_name; ?>"><?= $o->icon_name; ?></option>
                                <?php } ?>
                            </select>
                        </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-success">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>

<!-- hapus -->
<?php foreach ($interest as $i) : ?>
    <div id="hapus<?= $i->int_id; ?>" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Hapus Data</h3>
                </div>
                <div class="modal-body">
                    <h4>Anda ingin menghapus data <?= $i->int_id; ?></h4>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <a href="<?= site_url("interest/hapus/" . $i->int_id); ?>" class="btn btn-danger">Hapus</a>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>