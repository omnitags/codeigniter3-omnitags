<div class="col-12">
    <button class="btn btn-primary" data-toggle="modal" data-target="#tambah">
        <i class="fa fa-plus"></i> Add Data</button>
</div>
<div class="col-12">
    <table class="table table-hover mt-3" id="data">
        <thead>
            <tr>
                <th>Lang Id</th>
                <th>Id</th>
                <th>Name</th>
                <th>Percent</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (!$languages) {
                echo "<tr><td colspan='5' class='text-center'>tidak ada data tersedia</td></tr>";
            }

            foreach ($languages as $l) :
            ?>
                <tr>
                    <td><?= $l->lang_id; ?></td>
                    <td><?= $l->id; ?></td>
                    <td><?= $l->lang_name; ?></td>
                    <td><?= $l->lang_percent; ?></td>
                    <td>
                        <button class="btn btn-warning" data-toggle="modal" data-target="#edit<?= $l->lang_id; ?>">
                            <i class="fa-solid fa-pencil"></i>
                        </button>

                        <button class="btn btn-danger" data-toggle="modal" data-target="#hapus<?= $l->lang_id; ?>">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- tambah data -->
<div id="tambah" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Languages Data</h3>
            </div>
            <div class="modal-body">
                <form method="post" action="<?= site_url("Languages/tambah"); ?>">
                    <div class="form-group">
                        <label>Profile ID </label>
                        <select name="id" class="form-control" required>
                            <option value="" selected hidden>Choose your ID</option>
                            <?php foreach ($profile as $p) { ?>
                                <option value="<?= $p->id; ?>"><?= $p->id; ?></option>
                            <?php } ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Name</label>
                        <input type="text" class="form-control" name="lang_name" placeholder="ex: Indonesia">
                    </div>

                    <div class="form-group">
                        <label>Percent</label>
                        <input type="text" class="form-control" name="lang_percent" placeholder="ex: 90">
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-success">Simpan</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- edit data -->
<?php foreach ($languages as $l) : ?>
    <!-- edit -->
    <div id="edit<?= $l->lang_id; ?>" class="modal fade">

        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Edit Data Languages</h3>
                </div>
                <div class="modal-body">
                    <form method="post" action="<?= site_url("Languages/update"); ?>">
                        <div class="form-group">
                            <label>Languages ID</label>
                            <input type="text" class="form-control" name="lang_id" value="<?= $l->lang_id; ?>" readonly>
                        </div>

                        <div class="form-group">
                            <label>Profile Id</label>
                            <input type="text" class="form-control" name="id" value="<?= $l->id; ?>" readonly>
                        </div>

                        <div class="form-group">
                            <label>Name</label>
                            <input type="text" class="form-control" name="lang_name" value="<?= $l->lang_name; ?>">
                        </div>

                        <div class="form-group">
                            <label>Percent</label>
                            <input type="text" class="form-control" name="lang_percent" value="<?= $l->lang_percent; ?>">
                        </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-success">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>

<!-- hapus -->
<?php foreach ($languages as $l) : ?>
    <div id="hapus<?= $l->lang_id; ?>" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Hapus Data</h3>
                </div>
                <div class="modal-body">
                    <h4>Anda ingin menghapus data <?= $l->lang_id; ?></h4>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <a href="<?= site_url("languages/hapus/" . $l->lang_id); ?>" class="btn btn-danger">Hapus</a>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>