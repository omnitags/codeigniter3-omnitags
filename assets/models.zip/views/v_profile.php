<div class="col-12">
    <button class="btn btn-primary" data-toggle="modal" data-target="#tambah">
        <i class="fa fa-plus"></i> Tambah Data</button>
</div>
<div class="col-12">
    <table class="table table-hover mt-3" id="data">
        <thead>
            <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Work</th>
                <th>Phone</th>
                <th>Location</th>
                <th>Photo</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (!$profile) {
                echo "<tr><td colspan='5' class='text-center'>tidak ada data tersedia</td></tr>";
            }

            foreach ($profile as $p) :
            ?>
                <tr>
                    <td><?= $p->id; ?></td>
                    <td><?= $p->name; ?></td>
                    <td><?= $p->work; ?></td>
                    <td><?= $p->phone; ?></td>
                    <td><?= $p->location; ?></td>
                    <td><img class="rounded" src="<?= 'assets/upload/' . $p->photo; ?>" width="128" /></td>
                    <td>
                        <button class="btn btn-warning" data-toggle="modal" data-target="#edit<?= $p->id; ?>">
                            <i class="fa-solid fa-pencil"></i>
                        </button>

                        <button class="btn btn-danger" data-toggle="modal" data-target="#hapus<?= $p->id; ?>">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- tambah data -->
<div id="tambah" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Profile Data</h3>
            </div>
            <div class="modal-body">
                <form enctype="multipart/form-data" method="post" action="<?= site_url("Profile/tambah"); ?>">
                    <div class="form-group">
                        <label>Name</label>
                        <input type="text" class="form-control" name="name" placeholder="ex: Budi Setiawan">
                    </div>

                    <div class="form-group">
                        <label>Work</label>
                        <input type="text" class="form-control" name="work" placeholder="ex: Web Developer">
                    </div>

                    <div class="form-group">
                        <label>Description</label>
                        <textarea type="text" class="form-control" name="pro_description"></textarea>
                    </div>

                    <div class="form-group">
                        <label>Photo</label>
                        <input type="file" class="form-control-file" name="photo">
                    </div>
            </div>

            <div class="modal-header">
                <h4>Contact Data</h4>
            </div>
            <div class="modal-body">

                <div class="form-group">
                    <label>Phone</label>
                    <input type="text" class="form-control" name="phone" placeholder="ex: 08123456789">
                </div>

                <div class="form-group">
                    <label>Email</label>
                    <input type="text" class="form-control" name="email" placeholder="ex: name@gmail.com">
                </div>

                <div class="form-group">
                    <label>Web</label>
                    <input type="text" class="form-control" name="web" placeholder="ex: www.website.com">
                </div>

                <div class="form-group">
                    <label>Linkedin</label>
                    <input type="text" class="form-control" name="linkedin" placeholder="ex: linkedin.com/me">
                </div>

                <div class="form-group">
                    <label>Location</label>
                    <input type="text" class="form-control" name="location" placeholder="ex: Batam, Kepri, Indonesia">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-success">Simpan</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- edit data -->
<?php foreach ($profile as $p) : ?>
    <!-- edit -->
    <div id="edit<?= $p->id; ?>" class="modal fade">

        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Edit Data Profile</h3>
                </div>
                <div class="modal-body">
                    <form enctype="multipart/form-data" method="post" action="<?= site_url("Profile/update"); ?>">
                        <div class="form-group">
                            <label>Profile Id</label>
                            <input type="text" class="form-control" name="id" value="<?= $p->id; ?>" readonly>
                        </div>

                        <div class="form-group">
                            <label>Name</label>
                            <input type="text" class="form-control" name="name" value="<?= $p->name; ?>">
                        </div>

                        <div class="form-group">
                            <label>Work</label>
                            <input type="text" class="form-control" name="work" value="<?= $p->work; ?>">
                        </div>

                        <div class="form-group">
                            <label>Description</label>
                            <textarea type="text" class="form-control" name="pro_description"><?= $p->pro_description; ?></textarea>
                        </div>

                        <div class="form-group">
                            <label>Photo</label>
                            <input type="file" class="form-control-file" name="photo" value="">
                        </div>

                </div>

                <div class="modal-header">
                    <h4>Contact Data</h4>
                </div>
                <div class="modal-body">

                    <div class="form-group">
                        <label>Phone</label>
                        <input type="text" class="form-control" name="phone" value="<?= $p->phone; ?>">
                    </div>

                    <div class="form-group">
                        <label>Email</label>
                        <input type="text" class="form-control" name="email" value="<?= $p->email; ?>">
                    </div>

                    <div class="form-group">
                        <label>Web</label>
                        <input type="text" class="form-control" name="web" value="<?= $p->web; ?>">
                    </div>

                    <div class="form-group">
                        <label>Linkedin</label>
                        <input type="text" class="form-control" name="linkedin" value="<?= $p->linkedin; ?>">
                    </div>

                    <div class="form-group">
                        <label>Location</label>
                        <input type="text" class="form-control" name="location" value="<?= $p->location; ?>">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-success">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>

<!-- hapus -->
<?php foreach ($profile as $p) : ?>
    <div id="hapus<?= $p->id; ?>" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Hapus Data</h3>
                </div>
                <div class="modal-body">
                    <h4>Anda ingin menghapus profil <?= $p->name; ?></h4>
                    <p>Melakukan ini akan mengakibatkan data yang berhubungan dengan <?= $p->name; ?> juga ikut terhapus.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <a href="<?= site_url("profile/hapus/" . $p->id); ?>" class="btn btn-danger">Hapus</a>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>