<div class="col-12">
    <button class="btn btn-primary" data-toggle="modal" data-target="#tambah">
        <i class="fa fa-plus"></i> Add Data</button>
</div>
<div class="col-12">
    <table class="table table-hover mt-3" id="data">
        <thead>
            <tr>
                <th>skill id</th>
                <th>id</th>
                <th>name</th>
                <th>percent</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (!$skills) {
                echo "<tr><td colspan='5' class='text-center'>tidak ada data tersedia</td></tr>";
            }

            foreach ($skills as $s) :
            ?>
                <tr>
                    <td><?= $s->skill_id; ?></td>
                    <td><?= $s->id; ?></td>
                    <td><?= $s->skill_name; ?></td>
                    <td><?= $s->skill_percent; ?></td>
                    <td>
                        <button class="btn btn-warning" data-toggle="modal" data-target="#edit<?= $s->skill_id; ?>">
                            <i class="fa-solid fa-pencil"></i>
                        </button>

                        <button class="btn btn-danger" data-toggle="modal" data-target="#hapus<?= $s->skill_id; ?>">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- tambah data -->
<div id="tambah" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Skills Data</h3>
            </div>
            <div class="modal-body">
                <form method="post" action="<?= site_url("Skills/tambah"); ?>">
                    <div class="form-group">
                        <label>Profile ID </label>
                        <select name="id" class="form-control" required>
                            <option value="" selected hidden>Choose your ID</option>
                            <?php foreach ($profile as $p) { ?>
                                <option value="<?= $p->id; ?>"><?= $p->id; ?></option>
                            <?php } ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Name</label>
                        <input type="text" class="form-control" name="skill_name" placeholder="ex: Bahasa Indonesia">
                    </div>

                    <div class="form-group">
                        <label>Percent</label>
                        <input type="text" class="form-control" name="skill_percent" placeholder="ex: 80">
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-success">Simpan</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- edit data -->
<?php foreach ($skills as $s) : ?>
    <!-- edit -->
    <div id="edit<?= $s->skill_id; ?>" class="modal fade">

        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Edit Data Skills</h3>
                </div>
                <div class="modal-body">
                    <form method="post" action="<?= site_url("Skills/update"); ?>">
                        <div class="form-group">
                            <label>Skills ID</label>
                            <input type="text" class="form-control" name="skill_id" value="<?= $s->skill_id; ?>" readonly>
                        </div>

                        <div class="form-group">
                            <label>Profile Id</label>
                            <input type="text" class="form-control" name="id" value="<?= $s->id; ?>" readonly>
                        </div>

                        <div class="form-group">
                            <label>Name</label>
                            <input type="text" class="form-control" name="skill_name" value="<?= $s->skill_name; ?>">
                        </div>

                        <div class="form-group">
                            <label>Percent</label>
                            <input type="text" class="form-control" name="skill_percent" value="<?= $s->skill_percent; ?>">
                        </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-success">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>

<!-- hapus -->
<?php foreach ($skills as $s) : ?>
    <div id="hapus<?= $s->skill_id; ?>" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Hapus Data</h3>
                </div>
                <div class="modal-body">
                    <h4>Anda ingin menghapus data <?= $s->skill_id; ?></h4>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <a href="<?= site_url("skills/hapus/" . $s->skill_id); ?>" class="btn btn-danger">Hapus</a>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>