<!-- javascript untuk semua halaman (sesuai kebutuhan) -->
<script src="popper.min.js"></script>
<script src="jquery.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="fontawesome/js/all.min.js"></script>

<!-- javascript untuk datatables bertema bootstrap -->
<script src="datatables/datatables/js/jquery.dataTables.min.js"></script>
<script src="datatables/datatables/js/dataTables.bootstrap4.min.js"></script>
